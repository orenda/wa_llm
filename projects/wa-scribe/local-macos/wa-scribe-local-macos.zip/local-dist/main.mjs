import { chromium } from "@playwright/test";
import { createHash, randomUUID } from "node:crypto";
import { execFile } from "node:child_process";
import { link, lstat, mkdir, open, readFile, readdir, realpath, rename, rmdir, unlink } from "node:fs/promises";
import { homedir } from "node:os";
import { dirname, join, resolve, sep } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { promisify } from "node:util";
import { constants } from "node:fs";
//#region local/browser.ts
var MAX_BYTES = 8388608;
var DOWNLOAD_MARKERS = "[data-icon='download'], [data-testid='download'], [data-testid='download-button'], [aria-label='Download'], [title='Download'], a[download]";
var VIEWERS = ":is([data-testid='media-viewer'], [role='dialog']):not(#main *):not(#pane-side *):not([data-testid='media-viewer'] *):not([role='dialog'] *)";
var capturing = /* @__PURE__ */ new WeakSet();
function stopped(signal) {
	if (signal?.aborted) throw new Error("Collection stopped.");
}
function cssString(value) {
	return `"${Array.from(value, (char) => /[\x00-\x1f\x7f]/u.test(char) ? `\\${char.charCodeAt(0).toString(16)} ` : char === "\\" || char === "\"" ? `\\${char}` : char).join("")}"`;
}
function sameChat(actual, expected) {
	return actual.accountId === expected.accountId && actual.chatId === expected.chatId;
}
async function listChats(page) {
	return page.evaluate(() => window.waScribeLocal.catalog());
}
async function inspectPage(page) {
	return page.evaluate(() => window.waScribeLocal.inspect());
}
async function guardAccount(page, expected, signal) {
	stopped(signal);
	if (await page.evaluate(() => window.waScribeLocal.account()) !== expected.accountId) throw new Error("The WhatsApp account changed. Collection stopped.");
	stopped(signal);
}
async function delay(ms, signal) {
	await new Promise((resolve) => {
		const finish = () => {
			clearTimeout(timer);
			signal?.removeEventListener("abort", finish);
			resolve();
		};
		const timer = setTimeout(finish, ms);
		signal?.addEventListener("abort", finish, { once: true });
		if (signal?.aborted) finish();
	});
	stopped(signal);
}
async function matchingLabel(page, expected) {
	const hints = [...new Set([expected.name, ...expected.aliases ?? []].filter((name) => name.trim()))];
	const labels = page.locator("#pane-side [title]");
	const phone = /^(\d+)@(?:c\.us|s\.whatsapp\.net)$/.exec(expected.chatId)?.[1] ?? null;
	const matches = await labels.evaluateAll((nodes, input) => {
		const rows = /* @__PURE__ */ new Set();
		const indices = [];
		nodes.forEach((node, index) => {
			const title = node.getAttribute("title") ?? "";
			const phoneMatch = input.phone !== null && /^\+?[\d ()-]{7,32}$/.test(title) && title.replace(/\D/g, "") === input.phone;
			if (!input.hints.includes(title) && !phoneMatch) return;
			const row = node.closest("[role='row'], [role='listitem']");
			if (!row || rows.has(row) || node.closest("[hidden], [aria-hidden='true']")) return;
			const rect = node.getBoundingClientRect(), style = getComputedStyle(node);
			if (!rect.width || !rect.height || style.visibility === "hidden" || style.display === "none") return;
			rows.add(row);
			indices.push(index);
		});
		return indices;
	}, {
		hints,
		phone
	});
	if (matches.length > 1) throw new Error("More than one visible WhatsApp chat matches this chat's navigation hints.");
	return matches[0] === void 0 ? null : labels.nth(matches[0]);
}
async function openChat(page, expected, signal) {
	await guardAccount(page, expected, signal);
	const before = await inspectPage(page);
	if (before.ok && sameChat(before.chat, expected)) return before.chat;
	if (before.ok && before.chat.accountId !== expected.accountId) throw new Error("The WhatsApp account changed.");
	if (await page.locator("#pane-side").count() !== 1) throw new Error("WhatsApp's unique chat sidebar is unavailable.");
	const deadline = Date.now() + 12e3;
	let label = await matchingLabel(page, expected), search = null;
	if (!label) {
		const side = page.locator("#side");
		search = (await side.count() === 1 && await side.locator("#pane-side").count() === 1 && await side.locator("#main").count() === 0 ? side : page.locator("#pane-side")).locator("[contenteditable='true'][role='textbox'], input[role='combobox'], input[type='search']").filter({ visible: true });
		if (await search.count() !== 1) throw new Error("WhatsApp's sidebar search field is unavailable or ambiguous.");
		const phone = /^(\d+)@(?:c\.us|s\.whatsapp\.net)$/.exec(expected.chatId)?.[1];
		await guardAccount(page, expected, signal);
		await search.fill(expected.name === expected.chatId && phone ? phone : expected.name, { timeout: 3e3 });
		while (!label && Date.now() < deadline) {
			await guardAccount(page, expected, signal);
			label = await matchingLabel(page, expected);
			if (!label) await delay(150, signal);
		}
	}
	if (!label) throw new Error("The requested chat did not appear in WhatsApp's sidebar search.");
	await guardAccount(page, expected, signal);
	await label.click({ timeout: 3e3 });
	while (Date.now() < deadline) {
		await guardAccount(page, expected, signal);
		const current = await inspectPage(page);
		if (current.ok && sameChat(current.chat, expected)) {
			if (search) {
				await search.fill("", { timeout: 3e3 });
				await guardAccount(page, expected, signal);
				const cleared = await inspectPage(page);
				if (!cleared.ok || !sameChat(cleared.chat, expected)) throw new Error("The conversation changed while clearing WhatsApp search.");
			}
			return current.chat;
		}
		if (current.ok && (!before.ok || current.chat.chatId !== before.chat.chatId)) throw new Error("WhatsApp opened a different conversation. Collection stopped.");
		await delay(150, signal);
	}
	throw new Error("WhatsApp did not verify the requested conversation after navigation.");
}
function visibleViewers(page) {
	return page.locator(VIEWERS).filter({ visible: true });
}
function controls(root, markers) {
	return root.locator(markers).locator("xpath=ancestor-or-self::*[self::button or @role='button' or (self::a and @download)][1]").filter({ visible: true });
}
async function within(operation, deadline, signal) {
	let timer;
	let abort;
	try {
		return await Promise.race([operation, new Promise((_, reject) => {
			abort = () => reject(/* @__PURE__ */ new Error("Collection stopped."));
			timer = setTimeout(() => reject(/* @__PURE__ */ new Error("The attachment time budget was reached.")), Math.max(1, deadline - Date.now()));
			signal?.addEventListener("abort", abort, { once: true });
			if (signal?.aborted) abort();
		})]);
	} finally {
		if (timer) clearTimeout(timer);
		if (abort) signal?.removeEventListener("abort", abort);
	}
}
async function readDownload(download, deadline, signal) {
	let abandoned = false;
	const obtaining = download.createReadStream();
	obtaining.then((stream) => {
		if (abandoned) stream?.destroy();
	}, () => void 0);
	let stream = null;
	try {
		stream = await within(obtaining, deadline, signal);
		if (!stream) throw new Error("WhatsApp did not deliver readable original bytes.");
		const chunks = [];
		let size = 0;
		await within((async () => {
			if (!stream) throw new Error("The original download stream is unavailable.");
			for await (const chunk of stream) {
				const bytes = chunk instanceof Uint8Array ? chunk : null;
				if (!bytes) throw new Error("WhatsApp delivered an unsupported original stream.");
				size += bytes.byteLength;
				if (size > MAX_BYTES) throw new Error("The attachment exceeds the 8 MiB local prototype limit.");
				chunks.push(bytes);
			}
		})(), deadline, signal);
		const bytes = new Uint8Array(size);
		let offset = 0;
		for (const chunk of chunks) {
			bytes.set(chunk, offset);
			offset += chunk.byteLength;
		}
		return bytes;
	} finally {
		abandoned = true;
		stream?.destroy();
		await download.cancel();
		await download.delete();
	}
}
async function captureOriginal(page, expected, message, deadline, signal) {
	const initial = await page.evaluate((id) => window.waScribeLocal.row(id), message.id);
	if (!initial.ok || initial.text !== message.text) throw new Error("The attachment's keyed message changed before download.");
	const row = page.locator(`#main [data-id=${cssString(initial.rawId)}]`);
	if (await row.count() !== 1 || !await row.isVisible() || !await row.evaluate((node) => {
		const bounds = node.getBoundingClientRect();
		return bounds.bottom > 0 && bounds.right > 0 && bounds.top < innerHeight && bounds.left < innerWidth;
	})) throw new Error("The attachment is outside the current visible conversation window.");
	const metadata = await page.evaluate((id) => window.waScribeLocal.original(id), message.id);
	if (!metadata.ok) throw new Error(metadata.reason);
	const verify = async () => {
		stopped(signal);
		const inspection = await inspectPage(page);
		stopped(signal);
		const current = await page.evaluate((id) => window.waScribeLocal.row(id), message.id);
		stopped(signal);
		const original = await page.evaluate((id) => window.waScribeLocal.original(id), message.id);
		if (!inspection.ok || !sameChat(inspection.chat, expected) || !current.ok || current.rawId !== initial.rawId || current.text !== message.text || !original.ok || JSON.stringify(original.value) !== JSON.stringify(metadata.value) || await row.count() !== 1 || await row.locator("[data-icon*='view-once'], [data-testid*='view-once'], [data-icon='recalled'], [data-icon='recalled-out'], [data-testid='recalled']").count()) throw new Error("The attachment's account, conversation, message or original metadata changed.");
		stopped(signal);
	};
	let opened = null;
	try {
		await verify();
		if (await visibleViewers(page).count()) throw new Error("Close the existing WhatsApp media viewer before capturing attachments.");
		let buttons = controls(row, DOWNLOAD_MARKERS);
		if (await buttons.count() === 0) {
			const documentTile = row.locator("[data-testid='document-thumb']").filter({ visible: true });
			if (await documentTile.count() === 1) buttons = documentTile;
			else {
				const image = row.locator("img:not(.emoji)").filter({ visible: true });
				if (await image.count() !== 1 || await row.locator("video, audio").count()) throw new Error("This attachment has no supported individual original download control.");
				await verify();
				await image.click({ timeout: Math.max(1, Math.min(2e3, deadline - Date.now())) });
				const viewerDeadline = Math.min(deadline, Date.now() + 2e3);
				while (Date.now() < viewerDeadline) {
					const viewers = visibleViewers(page);
					if (await viewers.count() === 1) {
						opened = viewers;
						break;
					}
					if (await viewers.count() > 1) break;
					await delay(100, signal);
				}
				if (!opened) throw new Error("WhatsApp's original image viewer is unavailable or ambiguous.");
				buttons = controls(opened, DOWNLOAD_MARKERS);
			}
		}
		if (await buttons.count() !== 1) throw new Error("The original download control is unavailable or ambiguous.");
		await verify();
		let accepting = true;
		const pending = { download: null };
		const waiting = page.waitForEvent("download", {
			timeout: Math.max(1, Math.min(8e3, deadline - Date.now())),
			predicate: () => accepting
		}).then((download) => {
			pending.download = download;
			return {
				ok: true,
				download
			};
		}, () => ({ ok: false }));
		let received;
		try {
			await buttons.click({ timeout: Math.max(1, Math.min(2e3, deadline - Date.now())) });
			received = await within(waiting, deadline, signal);
		} catch (cause) {
			const late = pending.download ? {
				ok: true,
				download: pending.download
			} : await waiting;
			if (late.ok) {
				await late.download.cancel();
				await late.download.delete();
			}
			throw new Error("WhatsApp's original download was stopped or its control changed.", { cause });
		} finally {
			accepting = false;
		}
		if (!received.ok) throw new Error("WhatsApp did not deliver an original download within the time limit.");
		const name = metadata.value.name ?? received.download.suggestedFilename();
		const bytes = await readDownload(received.download, deadline, signal);
		await verify();
		if (createHash("sha256").update(bytes).digest("hex") !== metadata.value.digest.toLowerCase() || metadata.value.size !== null && bytes.byteLength !== metadata.value.size) throw new Error("The downloaded bytes did not match this message's original hash and size.");
		if (!name.trim() || name.length > 256 || name.includes("://") || /[\x00-\x1f\x7f/\\:]/u.test(name)) throw new Error("WhatsApp did not supply a safe original filename.");
		return {
			bytes,
			name,
			mediaType: metadata.value.mediaType,
			verify
		};
	} finally {
		if (opened && !signal?.aborted) {
			const inspection = await inspectPage(page);
			if (inspection.ok && sameChat(inspection.chat, expected) && await opened.count() === 1) {
				const close = controls(opened, "[data-icon='x-viewer'], [data-icon='x'], [aria-label='Close']");
				if (await close.count() === 1) await close.click({ timeout: 1e3 });
				else await page.keyboard.press("Escape");
			}
		}
	}
}
async function capturePass(page, expected, options, stash) {
	if (capturing.has(page)) throw new Error("Another attachment capture is already using this WhatsApp page.");
	capturing.add(page);
	try {
		await guardAccount(page, expected, options.signal);
		const deadline = Date.now() + 24e3;
		const collected = await page.evaluate((input) => window.waScribeLocal.collect(input), {
			expected,
			limit: Math.min(50, Math.max(1, options.limit)),
			maxMs: 12e3,
			scope: "visible"
		});
		if (options.scope === "loaded") collected.stopReason = "local-prototype-visible-window";
		options.onProgress?.(collected.messages.length);
		const deleted = new Set(collected.deletedIds);
		for (const message of collected.messages) {
			if (options.signal?.aborted || Date.now() >= deadline) {
				collected.stopReason = options.signal?.aborted ? "stopped" : "time-budget";
				break;
			}
			if (!message.attachments.length || deleted.has(message.id) || options.skipMediaIds?.has(message.id)) continue;
			const known = options.knownAttachments?.get(message.id);
			if (known?.some((entry) => entry.attachment.state === "saved" || entry.attachment.state === "opaque")) {
				message.attachments = message.attachments.map((entry) => known.find((item) => item.slot === entry.slot && (item.attachment.state === "saved" || item.attachment.state === "opaque")) ?? entry);
				continue;
			}
			if (message.attachments.some((entry) => entry.attachment.state === "unsupported")) continue;
			if (message.attachments.length !== 1) {
				message.attachments = message.attachments.map((entry) => ({
					slot: entry.slot,
					attachment: {
						state: "unavailable",
						limitation: "Individual originals in this media group could not be identified safely."
					}
				}));
				continue;
			}
			try {
				const original = await captureOriginal(page, expected, message, deadline, options.signal);
				stopped(options.signal);
				const attachment = await stash(original.bytes, original.name, original.mediaType);
				await original.verify();
				message.attachments = [{
					slot: message.attachments[0]?.slot ?? 1,
					attachment
				}];
			} catch (cause) {
				const limitation = cause instanceof Error && !cause.message.includes("\n") && cause.message.length < 240 ? cause.message : "WhatsApp's original attachment download could not be verified.";
				message.attachments = message.attachments.map((entry) => ({
					slot: entry.slot,
					attachment: {
						state: "unavailable",
						limitation
					}
				}));
			}
			const current = await inspectPage(page);
			if (!current.ok || !sameChat(current.chat, expected)) throw new Error("The WhatsApp account or conversation changed during attachment capture.");
			options.onProgress?.(collected.messages.length);
		}
		if (options.signal?.aborted) collected.stopReason = "stopped";
		await guardAccount(page, expected, options.signal?.aborted ? void 0 : options.signal);
		const final = await inspectPage(page);
		if (!final.ok || !sameChat(final.chat, expected)) throw new Error("The WhatsApp account or conversation changed before capture completed.");
		return collected;
	} finally {
		capturing.delete(page);
	}
}
//#endregion
//#region src/format.ts
var PRECISIONS = [
	"instant",
	"minute",
	"date",
	"display-only",
	"unknown"
];
var HEADER_SPECS = [
	{
		key: "sender-name",
		required: true
	},
	{
		key: "sender-key",
		required: false
	},
	{
		key: "time-display",
		required: true
	},
	{
		key: "time-precision",
		required: true
	},
	{
		key: "time-zone",
		required: false
	},
	{
		key: "instant",
		required: false
	},
	{
		key: "sequence",
		required: true
	},
	{
		key: "limitation",
		required: false
	}
];
function fail$1(outcome, reason, input) {
	return {
		ok: false,
		outcome,
		reason,
		input
	};
}
function isRecord(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function exactKeys(value, keys) {
	const got = Object.keys(value);
	return got.length === keys.length && keys.every((key) => got.includes(key));
}
/** Body lines that are structural sentinels, or that already start with a backslash, gain one backslash. */
function needsBodyEscape(line) {
	return line === "### message" || line === "## Transcript" || line.startsWith("\\");
}
function escapeBodyLine(line) {
	return needsBodyEscape(line) ? `\\${line}` : line;
}
function unescapeBodyLine(line) {
	if (!line.startsWith("\\")) return line;
	const rest = line.slice(1);
	if (rest === "### message" || rest === "## Transcript" || rest.startsWith("\\")) return rest;
	return null;
}
function escapeHeader(value) {
	return value.replaceAll("\\", "\\\\").replaceAll("\r", "\\r").replaceAll("\n", "\\n");
}
function unescapeHeader(value) {
	let out = "";
	for (let index = 0; index < value.length; index += 1) {
		const char = value[index];
		if (char === void 0) return null;
		if (char !== "\\") {
			out += char;
			continue;
		}
		const next = value[index + 1];
		if (next === "\\") out += "\\";
		else if (next === "n") out += "\n";
		else if (next === "r") out += "\r";
		else return null;
		index += 1;
	}
	return out;
}
function fnv1a(text) {
	let hash = 2166136261;
	for (const byte of new TextEncoder().encode(text)) {
		hash ^= byte;
		hash = Math.imul(hash, 16777619);
	}
	return (hash >>> 0).toString(16).padStart(8, "0");
}
function isPrecision(value) {
	return PRECISIONS.includes(value);
}
function isSequence(value) {
	return value === "verified" || value === "unknown";
}
function isSourceOrder(value) {
	return value === "verified" || value === "unknown";
}
function idOk(value) {
	return value.length > 0 && !value.includes("\n") && !value.includes("\r") && !value.includes("\0");
}
function isSafeRelative(path) {
	if (path === "" || path.startsWith("/") || path.includes("\\") || path.includes(":") || path.includes("?") || path.includes("#") || path.includes("\0")) return false;
	return path.split("/").every((part) => part !== "" && part !== "." && part !== "..");
}
function isPlainName(value) {
	return value.length > 0 && !value.includes("/") && !value.includes("\\") && !value.includes(":") && !value.includes("\0");
}
function isMediaType(value) {
	return value.length > 0 && !value.includes("://") && !value.includes("\\") && !value.includes("\0");
}
function attachmentOk(attachment) {
	if (attachment.state === "pending" || attachment.state === "unavailable") return attachment.limitation.length > 0 && !attachment.limitation.includes("://");
	if (attachment.state === "unsupported") return attachment.detail.length > 0 && !attachment.detail.includes("://");
	if (!isPlainName(attachment.name) || !isSafeRelative(attachment.relativePath) || encodedRelativePath(attachment.relativePath) === null) return false;
	if (attachment.state === "opaque") return attachment.mediaType === null || isMediaType(attachment.mediaType);
	return isMediaType(attachment.mediaType);
}
function canonicalAttachment(attachment) {
	if (attachment.state === "pending" || attachment.state === "unavailable") return {
		state: attachment.state,
		limitation: attachment.limitation
	};
	if (attachment.state === "unsupported") return {
		state: "unsupported",
		detail: attachment.detail
	};
	if (attachment.state === "opaque") return {
		state: "opaque",
		name: attachment.name,
		mediaType: attachment.mediaType,
		relativePath: attachment.relativePath
	};
	return {
		state: "saved",
		name: attachment.name,
		mediaType: attachment.mediaType,
		relativePath: attachment.relativePath
	};
}
function attachmentJson(attachment) {
	return JSON.stringify(canonicalAttachment(attachment));
}
function encodePathSegment(segment) {
	return encodeURIComponent(segment).replace(/[!'()*]/g, (character) => `%${character.charCodeAt(0).toString(16).toUpperCase()}`);
}
function encodedRelativePath(path) {
	try {
		return path.split("/").map(encodePathSegment).join("/");
	} catch {
		return null;
	}
}
function attachmentLinkLine(entry) {
	const attachment = entry.attachment;
	if (attachment.state !== "saved" && attachment.state !== "opaque") return null;
	const path = encodedRelativePath(attachment.relativePath);
	if (path === null) return null;
	return `attachment-link-${entry.slot}: [Open attachment](./${path})`;
}
function canonicalAttachments(message) {
	return {
		...message,
		attachments: message.attachments.map((entry) => ({
			slot: entry.slot,
			attachment: canonicalAttachment(entry.attachment)
		}))
	};
}
function sameSlots(left, right) {
	if (left.length !== right.length) return false;
	for (let index = 0; index < left.length; index += 1) {
		const first = left[index];
		const second = right[index];
		if (first === void 0 || second === void 0 || first.slot !== second.slot || attachmentJson(first.attachment) !== attachmentJson(second.attachment)) return false;
	}
	return true;
}
function knownInstantOk(value) {
	if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value)) return false;
	const parsed = new Date(value);
	return !Number.isNaN(parsed.getTime()) && parsed.toISOString() === value;
}
function timestampOk(timestamp) {
	if (!isPrecision(timestamp.precision)) return false;
	if (timestamp.precision !== "unknown" && timestamp.display === "") return false;
	if (timestamp.timeZone === "") return false;
	if (timestamp.precision === "instant") return timestamp.instant !== null && knownInstantOk(timestamp.instant);
	return timestamp.instant === null;
}
function messageShapeOk(message) {
	if (message.text.includes("\r") || message.limitation === "" || message.sender.key === "") return false;
	if (!timestampOk(message.timestamp) || !isSequence(message.sequence)) return false;
	const slots = /* @__PURE__ */ new Set();
	for (const entry of message.attachments) {
		if (!Number.isSafeInteger(entry.slot) || entry.slot < 1 || slots.has(entry.slot) || !attachmentOk(entry.attachment)) return false;
		slots.add(entry.slot);
	}
	return true;
}
function prefixProblem(prefix) {
	if (prefix === "") return false;
	if (!prefix.endsWith("\n")) return true;
	let start = 0;
	for (let index = 0; index <= prefix.length; index += 1) {
		if (index !== prefix.length && prefix[index] !== "\n") continue;
		let line = prefix.slice(start, index);
		if (line.endsWith("\r")) line = line.slice(0, -1);
		if (line === "## Transcript") return true;
		start = index + 1;
	}
	return false;
}
function renderBlock(message) {
	if (!messageShapeOk(message)) return null;
	const lines = ["### message", `sender-name: ${escapeHeader(message.sender.name)}`];
	if (message.sender.key !== null) lines.push(`sender-key: ${escapeHeader(message.sender.key)}`);
	lines.push(`time-display: ${escapeHeader(message.timestamp.display)}`, `time-precision: ${message.timestamp.precision}`);
	if (message.timestamp.timeZone !== null) lines.push(`time-zone: ${escapeHeader(message.timestamp.timeZone)}`);
	if (message.timestamp.instant !== null) lines.push(`instant: ${escapeHeader(message.timestamp.instant)}`);
	lines.push(`sequence: ${message.sequence}`);
	if (message.limitation !== null) lines.push(`limitation: ${escapeHeader(message.limitation)}`);
	for (const entry of message.attachments) {
		lines.push(`attachment: ${entry.slot} ${attachmentJson(entry.attachment)}`);
		const link = attachmentLinkLine(entry);
		if (link !== null) lines.push(link);
	}
	lines.push("");
	if (message.text !== "") for (const line of message.text.split("\n")) lines.push(escapeBodyLine(line));
	return `${lines.join("\n")}\n`;
}
function renderTranscript(prefix, messages) {
	if (prefixProblem(prefix)) return fail$1("parse-error", "invalid-prefix", prefix);
	let body = "";
	for (const message of messages) {
		const block = renderBlock(message);
		if (block === null) return fail$1("parse-error", "malformed-markdown", prefix);
		body += block;
	}
	return {
		ok: true,
		value: `${prefix}## Transcript\n${body}`
	};
}
function locateTranscript(input) {
	const hits = [];
	let start = 0;
	for (let index = 0; index <= input.length; index += 1) {
		if (index !== input.length && input[index] !== "\n") continue;
		let line = input.slice(start, index);
		const crlf = line.endsWith("\r");
		if (crlf) line = line.slice(0, -1);
		if (line === "## Transcript") hits.push({
			start,
			ending: crlf ? "\r\n" : index < input.length ? "\n" : ""
		});
		if (index === input.length) break;
		start = index + 1;
	}
	if (hits.length === 0) return "missing";
	if (hits.length > 1) return "ambiguous";
	const hit = hits[0];
	if (hit === void 0 || hit.ending !== "\n") return "ambiguous";
	return {
		prefix: input.slice(0, hit.start),
		generated: input.slice(hit.start + 14)
	};
}
function splitHeader(line) {
	const mark = line.indexOf(": ");
	if (mark <= 0) return null;
	const key = line.slice(0, mark);
	if (!/^[a-z-]+$/.test(key)) return null;
	const value = unescapeHeader(line.slice(mark + 2));
	if (value === null) return null;
	return {
		key,
		value
	};
}
function normalizeAttachment(value) {
	if (!isRecord(value) || typeof value.state !== "string") return null;
	if (value.state === "pending" || value.state === "unavailable") {
		if (!exactKeys(value, ["state", "limitation"]) || typeof value.limitation !== "string") return null;
		const attachment = {
			state: value.state,
			limitation: value.limitation
		};
		return attachmentOk(attachment) ? attachment : null;
	}
	if (value.state === "unsupported") {
		if (!exactKeys(value, ["state", "detail"]) || typeof value.detail !== "string") return null;
		const attachment = {
			state: "unsupported",
			detail: value.detail
		};
		return attachmentOk(attachment) ? attachment : null;
	}
	if (value.state !== "opaque" && value.state !== "saved") return null;
	if (!exactKeys(value, [
		"state",
		"name",
		"mediaType",
		"relativePath"
	])) return null;
	if (typeof value.name !== "string" || typeof value.relativePath !== "string") return null;
	if (value.state === "opaque") {
		if (value.mediaType !== null && typeof value.mediaType !== "string") return null;
		const attachment = {
			state: "opaque",
			name: value.name,
			mediaType: value.mediaType,
			relativePath: value.relativePath
		};
		return attachmentOk(attachment) ? attachment : null;
	}
	if (typeof value.mediaType !== "string") return null;
	const attachment = {
		state: "saved",
		name: value.name,
		mediaType: value.mediaType,
		relativePath: value.relativePath
	};
	return attachmentOk(attachment) ? attachment : null;
}
function readAttachment(line) {
	const matched = /^attachment: ([1-9]\d*) (\{.*\})$/.exec(line);
	const slotText = matched?.[1];
	const jsonText = matched?.[2];
	if (slotText === void 0 || jsonText === void 0) return null;
	try {
		const slot = Number(slotText);
		const attachment = normalizeAttachment(JSON.parse(jsonText));
		if (attachment === null || !Number.isSafeInteger(slot)) return null;
		return {
			slot,
			attachment
		};
	} catch {
		return null;
	}
}
function validAttachmentLink(line, entry) {
	return line === attachmentLinkLine(entry);
}
function timestampFrom(fields) {
	const display = fields.get("time-display");
	const precision = fields.get("time-precision");
	if (display === void 0 || precision === void 0 || !isPrecision(precision)) return null;
	const timestamp = {
		display,
		precision,
		timeZone: fields.has("time-zone") ? fields.get("time-zone") ?? null : null,
		instant: fields.has("instant") ? fields.get("instant") ?? null : null
	};
	return timestampOk(timestamp) ? timestamp : null;
}
function readBlock(lines, start) {
	if (lines[start] !== "### message") return null;
	const fields = /* @__PURE__ */ new Map();
	let index = start + 1;
	let specIndex = 0;
	while (specIndex < HEADER_SPECS.length) {
		const spec = HEADER_SPECS[specIndex];
		const line = lines[index];
		if (spec === void 0 || line === void 0) return null;
		if (line === "" || line.startsWith("attachment: ")) {
			if (spec.required) return null;
			specIndex += 1;
			continue;
		}
		const header = splitHeader(line);
		if (header === null || header.key !== spec.key) {
			if (spec.required) return null;
			specIndex += 1;
			continue;
		}
		fields.set(spec.key, header.value);
		specIndex += 1;
		index += 1;
	}
	const attachments = [];
	const seen = /* @__PURE__ */ new Set();
	const validatedLinkIndices = /* @__PURE__ */ new Set();
	while (lines[index] !== void 0 && lines[index] !== "") {
		const entry = readAttachment(lines[index] ?? "");
		if (entry === null || seen.has(entry.slot)) return null;
		seen.add(entry.slot);
		attachments.push(entry);
		index += 1;
		const linkLine = lines[index];
		const expectedLink = attachmentLinkLine(entry);
		if (linkLine?.startsWith("attachment-link-")) {
			if (expectedLink === null || !validAttachmentLink(linkLine, entry)) return null;
			validatedLinkIndices.add(index);
			index += 1;
		}
	}
	if (lines[index] !== "") return null;
	index += 1;
	const name = fields.get("sender-name");
	const sequence = fields.get("sequence");
	const timestamp = timestampFrom(fields);
	if (name === void 0 || sequence === void 0 || !isSequence(sequence) || timestamp === null) return null;
	const senderKey = fields.has("sender-key") ? fields.get("sender-key") ?? null : null;
	if (senderKey === "") return null;
	const limitation = fields.has("limitation") ? fields.get("limitation") ?? null : null;
	if (limitation === "") return null;
	const body = [];
	while (index < lines.length && lines[index] !== "### message") {
		const unescaped = unescapeBodyLine(lines[index] ?? "");
		if (unescaped === null) return null;
		body.push(unescaped);
		index += 1;
	}
	const blockText = `${lines.slice(start, index).filter((_, lineIndex) => !validatedLinkIndices.has(start + lineIndex)).join("\n")}\n`;
	return {
		block: {
			sender: {
				key: senderKey,
				name
			},
			timestamp,
			sequence,
			text: body.join("\n"),
			limitation,
			attachments,
			blockFingerprint: fnv1a(blockText)
		},
		next: index
	};
}
function parseGenerated(generated) {
	if (generated === "") return [];
	if (generated.includes("\r") || !generated.endsWith("\n")) return null;
	const lines = generated.slice(0, -1).split("\n");
	const blocks = [];
	let index = 0;
	while (index < lines.length) {
		const read = readBlock(lines, index);
		if (read === null) return null;
		blocks.push(read.block);
		index = read.next;
	}
	return blocks;
}
function parseTranscript(input) {
	const located = locateTranscript(input);
	if (located === "missing") return fail$1("parse-error", "malformed-markdown", input);
	if (located === "ambiguous") return fail$1("parse-error", "ambiguous-markdown", input);
	if (prefixProblem(located.prefix)) return fail$1("parse-error", "invalid-prefix", input);
	const blocks = parseGenerated(located.generated);
	if (blocks === null) return fail$1("parse-error", "malformed-markdown", input);
	return {
		ok: true,
		value: {
			prefix: located.prefix,
			blocks
		}
	};
}
function sameVisible(block, message) {
	return block.sequence === message.sequence && block.text === message.text && block.limitation === message.limitation && block.sender.key === message.sender.key && block.sender.name === message.sender.name && block.timestamp.display === message.timestamp.display && block.timestamp.precision === message.timestamp.precision && block.timestamp.timeZone === message.timestamp.timeZone && block.timestamp.instant === message.timestamp.instant && sameSlots(block.attachments, message.attachments);
}
function coverageOk(coverage, messages, sourceOrder) {
	if (coverage.requestedScope === "") return false;
	const seen = /* @__PURE__ */ new Set();
	for (const segment of coverage.segments) {
		if (segment.messageIds.length === 0) return false;
		if (segment.anchorBefore !== null && !idOk(segment.anchorBefore) || segment.anchorAfter !== null && !idOk(segment.anchorAfter)) return false;
		for (const id of segment.messageIds) {
			if (!idOk(id) || seen.has(id)) return false;
			seen.add(id);
		}
	}
	for (const message of messages) if (!seen.has(message.id)) return false;
	if (seen.size !== messages.length) return false;
	for (const gap of coverage.gaps) {
		if (gap.reason === "") return false;
		if (gap.afterId !== null && !idOk(gap.afterId) || gap.beforeId !== null && !idOk(gap.beforeId)) return false;
	}
	if (sourceOrder === "verified") {
		const ordered = coverage.segments.flatMap((segment) => segment.messageIds);
		if (coverage.gaps.length > 0 || ordered.length !== messages.length) return false;
		if (ordered.some((id, index) => id !== messages[index]?.id)) return false;
		if (messages.some((message) => message.sequence !== "verified")) return false;
	}
	return true;
}
function identityOk(chat) {
	if (!idOk(chat.accountId) || !idOk(chat.chatId) || !idOk(chat.destinationId) || !idOk(chat.generation)) return false;
	if (!idOk(chat.chatKey) || chat.displayName.includes("\0")) return false;
	const ids = /* @__PURE__ */ new Set();
	for (const message of chat.messages) {
		if (!idOk(message.id) || ids.has(message.id) || !messageShapeOk(message)) return false;
		ids.add(message.id);
	}
	const buried = /* @__PURE__ */ new Set();
	for (const tombstone of chat.tombstones) {
		if (tombstone.reason !== "local-deletion" || !idOk(tombstone.messageId) || ids.has(tombstone.messageId) || buried.has(tombstone.messageId)) return false;
		buried.add(tombstone.messageId);
	}
	return coverageOk(chat.coverage, chat.messages, chat.sourceOrder);
}
function fingerprintsOf(messages) {
	const rendered = renderTranscript("", messages);
	if (!rendered.ok) return null;
	const parsed = parseTranscript(rendered.value);
	if (!parsed.ok || parsed.value.blocks.length !== messages.length) return null;
	return parsed.value.blocks.map((block, index) => sameVisible(block, messages[index]) ? block.blockFingerprint : "");
}
function documentFrom(chat) {
	return {
		formatVersion: 1,
		accountId: chat.accountId,
		chatId: chat.chatId,
		chatKey: chat.chatKey,
		destinationId: chat.destinationId,
		generation: chat.generation,
		displayName: chat.displayName,
		sourceOrder: chat.sourceOrder,
		messages: chat.messages.map(canonicalAttachments),
		tombstones: chat.tombstones,
		coverage: chat.coverage
	};
}
function encodeMetadata(chat) {
	if (chat.formatVersion !== 1 || !identityOk(chat)) return fail$1("recovery-required", "missing-state", "");
	const fingerprints = fingerprintsOf(chat.messages);
	if (fingerprints === null) return fail$1("recovery-required", "missing-state", "");
	for (let index = 0; index < chat.messages.length; index += 1) if (chat.messages[index]?.blockFingerprint !== fingerprints[index]) return fail$1("recovery-required", "fingerprint-mismatch", "");
	return {
		ok: true,
		value: `${JSON.stringify(documentFrom(chat), null, 2)}\n`
	};
}
function encodeExport(prefix, draft) {
	if (!identityOk(draft)) return fail$1("recovery-required", "missing-state", prefix);
	const rendered = renderTranscript(prefix, draft.messages);
	if (!rendered.ok) return rendered;
	const parsed = parseTranscript(rendered.value);
	if (!parsed.ok || parsed.value.prefix !== prefix || parsed.value.blocks.length !== draft.messages.length) return fail$1("parse-error", "malformed-markdown", prefix);
	const messages = draft.messages.map((message, index) => canonicalAttachments({
		...message,
		blockFingerprint: parsed.value.blocks[index].blockFingerprint
	}));
	const chat = {
		...draft,
		formatVersion: 1,
		messages
	};
	const metadata = encodeMetadata(chat);
	if (!metadata.ok) return {
		...metadata,
		input: metadata.input || prefix
	};
	return {
		ok: true,
		value: {
			markdown: rendered.value,
			metadata: metadata.value,
			chat
		}
	};
}
function stringField(value, key) {
	const got = value[key];
	return typeof got === "string" ? got : null;
}
function nullableString(value) {
	if (value === null) return null;
	if (typeof value === "string") return value;
}
function readTimestamp(value) {
	if (!isRecord(value) || !exactKeys(value, [
		"display",
		"precision",
		"timeZone",
		"instant"
	])) return null;
	if (typeof value.display !== "string" || typeof value.precision !== "string" || !isPrecision(value.precision)) return null;
	const timeZone = nullableString(value.timeZone);
	const instant = nullableString(value.instant);
	if (timeZone === void 0 || instant === void 0) return null;
	const timestamp = {
		display: value.display,
		precision: value.precision,
		timeZone,
		instant
	};
	return timestampOk(timestamp) ? timestamp : null;
}
function readSlot(value) {
	if (!isRecord(value) || !exactKeys(value, ["slot", "attachment"]) || typeof value.slot !== "number") return null;
	const attachment = normalizeAttachment(value.attachment);
	if (attachment === null || !Number.isSafeInteger(value.slot) || value.slot < 1) return null;
	return {
		slot: value.slot,
		attachment
	};
}
function readMessage(value) {
	if (!isRecord(value)) return null;
	if (!exactKeys(value, [
		"id",
		"sender",
		"timestamp",
		"sequence",
		"text",
		"limitation",
		"attachments",
		"sourceBaseline",
		"savedWordingBaseline",
		"blockFingerprint"
	]) || typeof value.id !== "string" || typeof value.text !== "string") return null;
	if (typeof value.sequence !== "string" || !isSequence(value.sequence)) return null;
	if (typeof value.sourceBaseline !== "string" || typeof value.savedWordingBaseline !== "string") return null;
	if (typeof value.blockFingerprint !== "string" || !/^[0-9a-f]{8}$/.test(value.blockFingerprint)) return null;
	const limitation = nullableString(value.limitation);
	if (limitation === void 0 || !isRecord(value.sender) || !exactKeys(value.sender, ["key", "name"])) return null;
	const senderKey = nullableString(value.sender.key);
	if (senderKey === void 0 || typeof value.sender.name !== "string" || !Array.isArray(value.attachments)) return null;
	const timestamp = readTimestamp(value.timestamp);
	if (timestamp === null) return null;
	const attachments = [];
	for (const entry of value.attachments) {
		const slot = readSlot(entry);
		if (slot === null) return null;
		attachments.push(slot);
	}
	const message = {
		id: value.id,
		sender: {
			key: senderKey,
			name: value.sender.name
		},
		timestamp,
		sequence: value.sequence,
		text: value.text,
		limitation,
		attachments,
		sourceBaseline: value.sourceBaseline,
		savedWordingBaseline: value.savedWordingBaseline,
		blockFingerprint: value.blockFingerprint
	};
	return messageShapeOk(message) ? message : null;
}
function readCoverage(value) {
	if (!isRecord(value) || !exactKeys(value, [
		"segments",
		"gaps",
		"requestedScope",
		"stopReason"
	])) return null;
	if (typeof value.requestedScope !== "string" || !Array.isArray(value.segments) || !Array.isArray(value.gaps)) return null;
	const stopReason = nullableString(value.stopReason);
	if (stopReason === void 0) return null;
	const segments = [];
	for (const entry of value.segments) {
		if (!isRecord(entry) || !exactKeys(entry, [
			"messageIds",
			"anchorBefore",
			"anchorAfter"
		]) || !Array.isArray(entry.messageIds)) return null;
		const anchorBefore = nullableString(entry.anchorBefore);
		const anchorAfter = nullableString(entry.anchorAfter);
		if (anchorBefore === void 0 || anchorAfter === void 0) return null;
		const messageIds = [];
		for (const id of entry.messageIds) {
			if (typeof id !== "string") return null;
			messageIds.push(id);
		}
		segments.push({
			messageIds,
			anchorBefore,
			anchorAfter
		});
	}
	const gaps = [];
	for (const entry of value.gaps) {
		if (!isRecord(entry) || !exactKeys(entry, [
			"afterId",
			"beforeId",
			"reason"
		]) || typeof entry.reason !== "string") return null;
		const afterId = nullableString(entry.afterId);
		const beforeId = nullableString(entry.beforeId);
		if (afterId === void 0 || beforeId === void 0) return null;
		gaps.push({
			afterId,
			beforeId,
			reason: entry.reason
		});
	}
	return {
		segments,
		gaps,
		requestedScope: value.requestedScope,
		stopReason
	};
}
function readChat(value) {
	if (!isRecord(value)) return null;
	if (!exactKeys(value, [
		"formatVersion",
		"accountId",
		"chatId",
		"chatKey",
		"destinationId",
		"generation",
		"displayName",
		"sourceOrder",
		"messages",
		"tombstones",
		"coverage"
	]) || value.formatVersion !== 1 || !Array.isArray(value.messages) || !Array.isArray(value.tombstones)) return null;
	const accountId = stringField(value, "accountId");
	const chatId = stringField(value, "chatId");
	const chatKey = stringField(value, "chatKey");
	const destinationId = stringField(value, "destinationId");
	const generation = stringField(value, "generation");
	const displayName = stringField(value, "displayName");
	if (accountId === null || chatId === null || chatKey === null || destinationId === null || generation === null || displayName === null) return null;
	if (typeof value.sourceOrder !== "string" || !isSourceOrder(value.sourceOrder)) return null;
	const messages = [];
	for (const entry of value.messages) {
		const message = readMessage(entry);
		if (message === null) return null;
		messages.push(message);
	}
	const tombstones = [];
	for (const entry of value.tombstones) {
		if (!isRecord(entry) || !exactKeys(entry, ["messageId", "reason"]) || entry.reason !== "local-deletion" || typeof entry.messageId !== "string") return null;
		tombstones.push({
			messageId: entry.messageId,
			reason: "local-deletion"
		});
	}
	const coverage = readCoverage(value.coverage);
	if (coverage === null) return null;
	return {
		formatVersion: 1,
		accountId,
		chatId,
		chatKey,
		destinationId,
		generation,
		displayName,
		sourceOrder: value.sourceOrder,
		messages,
		tombstones,
		coverage
	};
}
function sameBinding$1(chat, expected) {
	return chat.accountId === expected.accountId && chat.chatId === expected.chatId && chat.destinationId === expected.destinationId && chat.generation === expected.generation;
}
function decodeMetadata(input, expected) {
	let parsed;
	try {
		parsed = JSON.parse(input);
	} catch {
		return fail$1("recovery-required", "invalid-json", input);
	}
	if (!isRecord(parsed) || !("formatVersion" in parsed)) return fail$1("recovery-required", "missing-state", input);
	if (parsed.formatVersion !== 1) return fail$1("recovery-required", "unsupported-version", input);
	const chat = readChat(parsed);
	if (chat === null || !identityOk(chat)) return fail$1("recovery-required", "missing-state", input);
	if (!sameBinding$1(chat, expected)) return fail$1("recovery-required", "binding-mismatch", input);
	const fingerprints = fingerprintsOf(chat.messages);
	if (fingerprints === null) return fail$1("recovery-required", "missing-state", input);
	for (let index = 0; index < chat.messages.length; index += 1) if (chat.messages[index]?.blockFingerprint !== fingerprints[index]) return fail$1("recovery-required", "fingerprint-mismatch", input);
	return {
		ok: true,
		value: chat
	};
}
//#endregion
//#region src/download.ts
function pause(reason, markdown, chat, unresolved = []) {
	return {
		phase: "paused",
		reason,
		markdown,
		metadata: null,
		chat,
		inserted: [],
		unresolved
	};
}
function sameBinding(left, right) {
	return left.accountId === right.accountId && left.chatId === right.chatId && left.destinationId === right.destinationId && left.generation === right.generation;
}
/** Both chains must establish a unique order; array position is not new evidence. */
function mergeIds(committed, observed, contiguous) {
	const saved = new Set(committed);
	if (committed.length && observed.length && !observed.some((id) => saved.has(id))) return { disjoint: [...observed] };
	const edges = /* @__PURE__ */ new Map();
	const incoming = /* @__PURE__ */ new Map();
	for (const id of [...committed, ...observed]) {
		if (!edges.has(id)) edges.set(id, /* @__PURE__ */ new Set());
		if (!incoming.has(id)) incoming.set(id, 0);
	}
	const connect = (before, after) => {
		if (!before || !after || before === after || edges.get(before)?.has(after)) return;
		edges.get(before)?.add(after);
		incoming.set(after, (incoming.get(after) ?? 0) + 1);
	};
	for (const chain of [committed, observed]) for (let index = 1; index < chain.length; index += 1) connect(chain[index - 1], chain[index]);
	if (contiguous) {
		const anchors = observed.map((id, index) => saved.has(id) ? index : -1).filter((index) => index >= 0);
		const first = anchors[0];
		const last = anchors.at(-1);
		if (first !== void 0 && first > 0) connect(committed[committed.indexOf(observed[first] ?? "") - 1], observed[0]);
		if (last !== void 0 && last < observed.length - 1) connect(observed.at(-1), committed[committed.indexOf(observed[last] ?? "") + 1]);
	}
	const ids = [];
	const ready = [...incoming].filter(([, degree]) => degree === 0).map(([id]) => id);
	while (ready.length === 1) {
		const id = ready.pop();
		if (id === void 0) break;
		ids.push(id);
		for (const next of edges.get(id) ?? []) {
			const degree = (incoming.get(next) ?? 0) - 1;
			incoming.set(next, degree);
			if (degree === 0) ready.push(next);
		}
	}
	return ids.length === incoming.size ? { ids } : { conflict: true };
}
function blockKey(block) {
	const attachments = block.attachments.map(({ slot, attachment }) => {
		if (attachment.state === "pending" || attachment.state === "unavailable") return [
			slot,
			attachment.state,
			attachment.limitation
		];
		if (attachment.state === "unsupported") return [
			slot,
			attachment.state,
			attachment.detail
		];
		return [
			slot,
			attachment.state,
			attachment.name,
			attachment.mediaType,
			attachment.relativePath
		];
	});
	return JSON.stringify([
		block.blockFingerprint,
		block.sender.key,
		block.sender.name,
		block.timestamp.display,
		block.timestamp.precision,
		block.timestamp.timeZone,
		block.timestamp.instant,
		block.sequence,
		block.text,
		block.limitation,
		attachments
	]);
}
function uniqueKept(messages, blocks) {
	if (!blocks.length) return [];
	if (blocks.length > messages.length) return "ambiguous";
	const saved = messages.map(blockKey);
	const current = blocks.map(blockKey);
	if (saved.length === current.length) return saved.every((key, index) => key === current[index]) ? saved.map((_, index) => index) : "ambiguous";
	const width = current.length + 1;
	if ((saved.length + 1) * width > 1e6) return "ambiguous";
	const ways = new Uint8Array((saved.length + 1) * width);
	for (let index = 0; index <= saved.length; index += 1) ways[index * width + current.length] = 1;
	for (let index = saved.length - 1; index >= 0; index -= 1) for (let block = current.length - 1; block >= 0; block -= 1) ways[index * width + block] = Math.min(2, (ways[(index + 1) * width + block] ?? 0) + (saved[index] === current[block] ? ways[(index + 1) * width + block + 1] ?? 0 : 0));
	if (ways[0] !== 1) return "ambiguous";
	const kept = [];
	for (let index = 0, block = 0; index < saved.length && block < current.length; index += 1) if (saved[index] === current[block] && ways[(index + 1) * width + block + 1]) {
		kept.push(index);
		block += 1;
	}
	return kept;
}
function applyLocalDeletions(markdown, chat) {
	const parsed = parseTranscript(markdown);
	if (!parsed.ok) return {
		reason: "ambiguous-local",
		unresolved: []
	};
	const kept = uniqueKept(chat.messages, parsed.value.blocks);
	if (kept === "ambiguous") {
		const sameLength = parsed.value.blocks.length === chat.messages.length;
		const currentKeys = parsed.value.blocks.map(blockKey);
		return {
			reason: sameLength ? "local-edit" : "ambiguous-local",
			unresolved: sameLength ? chat.messages.filter((message, index) => blockKey(message) !== currentKeys[index]).map((message) => message.id) : []
		};
	}
	const keep = new Set(kept);
	const removed = chat.messages.filter((_, index) => !keep.has(index));
	const messages = chat.messages.filter((_, index) => keep.has(index));
	const tombstones = [...chat.tombstones, ...removed.map((message) => ({
		messageId: message.id,
		reason: "local-deletion"
	}))];
	return {
		chat: {
			...chat,
			messages,
			tombstones
		},
		prefix: parsed.value.prefix
	};
}
function gapsFor(ids, coverage, observed, contiguous) {
	const present = new Set(ids);
	const adjacency = /* @__PURE__ */ new Map();
	const connect = (before, after) => {
		if (!before || !after) return;
		if (!adjacency.has(before)) adjacency.set(before, /* @__PURE__ */ new Set());
		adjacency.get(before)?.add(after);
	};
	for (const segment of coverage?.segments ?? []) {
		const kept = segment.messageIds.filter((id) => present.has(id));
		for (let index = 1; index < kept.length; index += 1) connect(kept[index - 1], kept[index]);
	}
	const previousIds = coverage?.segments.flatMap((segment) => segment.messageIds) ?? [];
	for (const gap of coverage?.gaps ?? []) {
		if (gap.afterId === null || gap.beforeId === null) continue;
		const start = previousIds.indexOf(gap.afterId);
		const end = previousIds.indexOf(gap.beforeId);
		if (start < 0 || end <= start) continue;
		for (let index = start; index < end; index += 1) adjacency.get(previousIds[index] ?? "")?.delete(previousIds[index + 1] ?? "");
	}
	if (contiguous) {
		const kept = observed.filter((id) => present.has(id));
		for (let index = 1; index < kept.length; index += 1) connect(kept[index - 1], kept[index]);
	}
	const gaps = [];
	const add = (gap) => {
		if (!gaps.some((entry) => entry.afterId === gap.afterId && entry.beforeId === gap.beforeId)) gaps.push(gap);
	};
	for (const gap of coverage?.gaps ?? []) if (!(contiguous && gap.afterId !== null && gap.beforeId !== null && observed.includes(gap.afterId) && observed.includes(gap.beforeId)) && (gap.afterId === null || gap.beforeId === null || !present.has(gap.afterId) || !present.has(gap.beforeId))) add({
		...gap,
		afterId: gap.afterId !== null && present.has(gap.afterId) ? gap.afterId : null,
		beforeId: gap.beforeId !== null && present.has(gap.beforeId) ? gap.beforeId : null
	});
	for (let index = 1; index < ids.length; index += 1) {
		const afterId = ids[index - 1];
		const beforeId = ids[index];
		if (afterId && beforeId && !adjacency.get(afterId)?.has(beforeId)) add({
			afterId,
			beforeId,
			reason: "unverified-between"
		});
	}
	return gaps;
}
function segmentsFor(ids, gaps) {
	const splitAfter = new Set(gaps.map((gap) => gap.afterId));
	const segments = [];
	let current = [];
	for (const id of ids) {
		current.push(id);
		if (splitAfter.has(id)) {
			segments.push({
				messageIds: current,
				anchorBefore: null,
				anchorAfter: null
			});
			current = [];
		}
	}
	if (current.length) segments.push({
		messageIds: current,
		anchorBefore: null,
		anchorAfter: null
	});
	return segments;
}
function draftsFor(ids, chat, observed) {
	const saved = new Map((chat?.messages ?? []).map((message) => [message.id, message]));
	const seen = new Map(observed.map((message) => [message.id, message]));
	const messages = [];
	for (const id of ids) {
		const existing = saved.get(id);
		const next = seen.get(id);
		if (existing) {
			const observedAttachments = new Map((next?.attachments ?? []).map((entry) => [entry.slot, entry.attachment]));
			const attachments = existing.attachments.map((entry) => {
				const newer = observedAttachments.get(entry.slot);
				if ((entry.attachment.state === "pending" || entry.attachment.state === "unavailable") && newer !== void 0 && (newer.state === "saved" || newer.state === "opaque")) return {
					slot: entry.slot,
					attachment: newer
				};
				return entry;
			});
			messages.push({
				...existing,
				attachments,
				sourceBaseline: next?.sourceBaseline ?? existing.sourceBaseline
			});
		} else if (next) messages.push({
			id: next.id,
			sender: next.sender,
			timestamp: next.timestamp,
			sequence: next.sequence,
			text: next.text,
			attachments: next.attachments,
			limitation: null,
			sourceBaseline: next.sourceBaseline,
			savedWordingBaseline: next.sourceBaseline
		});
	}
	return messages;
}
function downloadPass(input) {
	if (input.chat && !sameBinding(input.chat, input.binding)) return pause("binding-mismatch", input.markdown, input.chat);
	if (input.chat === null !== (input.markdown === null)) return pause("missing-state", input.markdown, input.chat);
	const originalMetadata = input.chat ? encodeMetadata(input.chat) : null;
	if (originalMetadata && !originalMetadata.ok) return pause("missing-state", input.markdown, input.chat);
	let chat = input.chat;
	let prefix = input.prefix;
	if (chat && input.markdown !== null) {
		const local = applyLocalDeletions(input.markdown, chat);
		if ("reason" in local) return pause(local.reason, input.markdown, chat, local.unresolved);
		chat = local.chat;
		prefix = local.prefix;
	}
	const buried = new Set((chat?.tombstones ?? []).map((tombstone) => tombstone.messageId));
	const observedIds = input.observed.map((message) => message.id).filter((id) => !buried.has(id));
	if (new Set(observedIds).size !== observedIds.length || observedIds.some((id) => id === "")) return pause("unknown-order", input.markdown, input.chat, observedIds);
	if (input.order !== "verified") {
		const unresolved = observedIds.filter((id) => !chat?.messages.some((message) => message.id === id));
		if (unresolved.length) return pause("unknown-order", input.markdown, input.chat, unresolved);
	}
	const merged = mergeIds(chat?.messages.map((message) => message.id) ?? [], observedIds, input.contiguous && input.order === "verified");
	if ("conflict" in merged) return pause("unknown-order", input.markdown, input.chat, observedIds);
	if ("disjoint" in merged) return pause("disjoint", input.markdown, input.chat, merged.disjoint);
	const inserted = merged.ids.filter((id) => !chat?.messages.some((message) => message.id === id));
	const gaps = gapsFor(merged.ids, chat?.coverage, input.observed.map((message) => message.id), input.contiguous && input.order === "verified");
	const stopReason = input.stopReason || (input.requestedScope === "visible" ? "visible-window" : "scope-boundary-unverified");
	const messages = draftsFor(merged.ids, chat, input.observed);
	const draft = {
		...input.binding,
		chatKey: chat?.chatKey ?? input.chatKey,
		displayName: input.displayName,
		sourceOrder: gaps.length === 0 && messages.every((message) => message.sequence === "verified") ? "verified" : "unknown",
		messages,
		tombstones: chat?.tombstones ?? [],
		coverage: {
			segments: segmentsFor(merged.ids, gaps),
			gaps,
			requestedScope: input.requestedScope,
			stopReason
		}
	};
	const encoded = encodeExport(prefix, draft);
	if (!encoded.ok) return pause("missing-state", input.markdown, input.chat);
	return {
		phase: input.markdown === encoded.value.markdown && originalMetadata?.ok === true && originalMetadata.value === encoded.value.metadata ? "unchanged" : "updated",
		reason: null,
		markdown: encoded.value.markdown,
		metadata: encoded.value.metadata,
		chat: encoded.value.chat,
		inserted,
		unresolved: []
	};
}
//#endregion
//#region src/media-stage.ts
var MAX_FILE = 8388608;
var KEY = /^[0-9a-f]{64}$/;
function mediaDescriptor(key, name, mediaType, size) {
	if (!KEY.test(key) || !Number.isSafeInteger(size) || size < 0 || size > MAX_FILE || typeof name !== "string") throw new Error("Invalid staged attachment.");
	const cleanName = name.replace(/[\x00-\x1f\x7f/\\:]/g, "_").trim().slice(0, 256) || "attachment";
	const type = mediaType === null || mediaType === "" ? null : mediaType.split(";", 1)[0]?.trim().toLowerCase() ?? null;
	if (type !== null && (type.length > 128 || !/^[a-z0-9!#$&^_.+-]+\/[a-z0-9!#$&^_.+-]+$/.test(type))) throw new Error("Invalid attachment media type.");
	return {
		key,
		relativePath: `${key}.${(type ? {
			"application/pdf": "pdf",
			"image/jpeg": "jpg",
			"image/png": "png",
			"image/webp": "webp",
			"image/gif": "gif",
			"audio/ogg": "ogg",
			"video/mp4": "mp4"
		}[type] : void 0) ?? /\.([a-z0-9]{1,10})$/i.exec(cleanName)?.[1]?.toLowerCase() ?? "bin"}`,
		name: cleanName,
		mediaType: type,
		size
	};
}
//#endregion
//#region local/store.ts
var TEXT_LIMIT = 262144;
var FILE_LIMIT = 8388608;
var TOTAL_LIMIT = 33554432;
var UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
var LEAF = /^([0-9a-f]{64})\.[a-z0-9]{1,10}$/;
var digest = (bytes) => createHash("sha256").update(bytes).digest("hex");
var missing = (error) => error instanceof Error && "code" in error && error.code === "ENOENT";
var record$1 = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
function fail(message) {
	throw new Error(message);
}
function identity(expected) {
	if (typeof expected.accountId !== "string" || !expected.accountId || typeof expected.chatId !== "string" || !expected.chatId || typeof expected.name !== "string") fail("Unverifiable account or chat identity.");
	return digest(JSON.stringify([expected.accountId, expected.chatId])).slice(0, 16);
}
async function directory(path, create = false) {
	if (create) try {
		await mkdir(path);
	} catch (error) {
		if (!(error instanceof Error && "code" in error && error.code === "EEXIST")) throw error;
	}
	const stat = await lstat(path);
	if (!stat.isDirectory() || stat.isSymbolicLink()) fail("Export directories must be real directories, without symlinks.");
}
async function read(path, limit) {
	let handle;
	try {
		handle = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
	} catch (error) {
		if (missing(error)) return null;
		throw error;
	}
	try {
		const stat = await handle.stat();
		if (!stat.isFile() || stat.size > limit) fail("Export file is invalid or exceeds its size limit.");
		const bytes = await handle.readFile();
		if (bytes.byteLength > limit) fail("Export file grew beyond its size limit.");
		return bytes;
	} finally {
		await handle.close();
	}
}
async function text(path, limit = TEXT_LIMIT) {
	const bytes = await read(path, limit);
	return bytes === null ? null : new TextDecoder("utf-8", { fatal: true }).decode(bytes);
}
async function syncDirectory(path) {
	const handle = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
	try {
		await handle.sync();
	} finally {
		await handle.close();
	}
}
async function atomic(path, bytes, exclusive = false) {
	const temporary = join(dirname(path), `.writing-${randomUUID()}`);
	const handle = await open(temporary, constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW, 384);
	try {
		await handle.writeFile(bytes);
		await handle.sync();
	} finally {
		await handle.close();
	}
	if (exclusive) {
		try {
			await link(temporary, path);
		} catch (error) {
			if (!(error instanceof Error && "code" in error && error.code === "EEXIST")) throw error;
			const installed = await read(path, typeof bytes === "string" ? TEXT_LIMIT : FILE_LIMIT);
			if (installed === null || digest(installed) !== digest(bytes)) fail("Exclusive file publication found different existing content.");
		}
		await unlink(temporary);
	} else await rename(temporary, path);
	await syncDirectory(dirname(path));
}
async function immutable(path, bytes) {
	const prior = await read(path, typeof bytes === "string" ? TEXT_LIMIT : FILE_LIMIT);
	if (prior !== null) {
		if (digest(prior) !== digest(bytes)) fail("Immutable generation content changed; preserve it for manual recovery.");
	} else await atomic(path, bytes, true);
}
function pairHash(pointer, markdown, metadata) {
	return digest(JSON.stringify([
		pointer,
		markdown,
		metadata
	]));
}
function decode(metadata, binding) {
	const decoded = decodeMetadata(metadata, binding);
	if (!decoded.ok) fail(`Export metadata requires recovery: ${decoded.reason}.`);
	if (decoded.value.chatKey !== digest(JSON.stringify([binding.accountId, binding.chatId])).slice(0, 16)) fail("Export chat key does not match its bound identity.");
	return decoded.value;
}
function verifyPair(pending, binding) {
	if (Buffer.byteLength(pending.markdown) + Buffer.byteLength(pending.metadata) > TEXT_LIMIT) fail("Pending transcript exceeds 256 KiB.");
	const chat = decode(pending.metadata, binding), parsed = parseTranscript(pending.markdown);
	if (!parsed.ok) fail("Pending transcript is invalid.");
	const encoded = encodeExport(parsed.value.prefix, chat);
	if (!encoded.ok || encoded.value.markdown !== pending.markdown || encoded.value.metadata !== pending.metadata) fail("Pending transcript and metadata do not match.");
	return chat;
}
async function createStore(output, hooks = {}) {
	const requested = resolve(output);
	await mkdir(requested, { recursive: true });
	await directory(requested);
	const root = await realpath(requested), lock = join(root, ".wa-scribe.lock"), owner = randomUUID();
	try {
		await mkdir(lock, { mode: 448 });
	} catch (error) {
		if (error instanceof Error && "code" in error && error.code === "EEXIST") fail("Output is locked. Stop its owning wa-scribe process first; then manually remove .wa-scribe.lock only after confirming no writer is running. Stale locks are never cleared automatically.");
		throw error;
	}
	const lockStat = await lstat(lock);
	const ownerPath = join(lock, "owner"), staging = join(root, ".staging");
	let ownerStat = null, ownerComplete = false;
	try {
		const handle = await open(ownerPath, constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW, 384);
		try {
			ownerStat = await handle.stat();
			await handle.writeFile(owner);
			await handle.sync();
			ownerComplete = true;
		} finally {
			await handle.close();
		}
		await syncDirectory(lock);
		await directory(staging, true);
		await syncDirectory(root);
	} catch (cause) {
		try {
			const present = await lstat(lock);
			if (!present.isDirectory() || present.isSymbolicLink() || present.dev !== lockStat.dev || present.ino !== lockStat.ino) fail("Initialization lock ownership changed; the foreign lock was preserved.");
			const presentOwner = await lstat(ownerPath).catch((error) => {
				if (missing(error)) return null;
				throw error;
			});
			if (ownerComplete && presentOwner === null) fail("Initialization owner token disappeared; the lock was preserved.");
			if (presentOwner !== null) {
				if (!ownerStat || !presentOwner.isFile() || presentOwner.isSymbolicLink() || presentOwner.dev !== ownerStat.dev || presentOwner.ino !== ownerStat.ino || ownerComplete && await text(ownerPath, 128) !== owner) fail("Initialization owner file changed; the foreign lock was preserved.");
				await unlink(ownerPath);
			}
			const latest = await lstat(lock);
			if (latest.dev !== lockStat.dev || latest.ino !== lockStat.ino || latest.isSymbolicLink()) fail("Initialization lock changed before cleanup; it was preserved.");
			await rmdir(lock);
			await syncDirectory(root);
		} catch (cleanupError) {
			throw new AggregateError([cause, cleanupError], "Local store initialization failed and its lock could not be safely released. Stop the owning process before manually reviewing .wa-scribe.lock.", { cause });
		}
		throw cause;
	}
	let closed = false, queue = Promise.resolve(), closing;
	const snapshots = /* @__PURE__ */ new Map();
	const run = (action) => {
		const next = queue.then(async () => {
			if (closed) fail("Local store is closed.");
			const stat = await lstat(lock);
			if (!stat.isDirectory() || stat.isSymbolicLink() || stat.dev !== lockStat.dev || stat.ino !== lockStat.ino || await text(join(lock, "owner"), 128) !== owner) fail("Output lock ownership changed; preserve the foreign lock.");
			return action();
		});
		queue = next.then(() => void 0, () => void 0);
		return next;
	};
	async function bound(expected) {
		const path = join(root, identity(expected));
		await directory(path, true);
		let raw = await text(join(path, "binding.json"));
		if (raw === null) {
			if ((await readdir(path)).length) fail("Chat directory has files but no binding; existing exports cannot be adopted.");
			const binding = {
				accountId: expected.accountId,
				chatId: expected.chatId,
				destinationId: randomUUID(),
				generation: randomUUID()
			};
			await immutable(join(path, "binding.json"), `${JSON.stringify(binding)}\n`);
			await syncDirectory(root);
			raw = JSON.stringify(binding);
		}
		const value = JSON.parse(raw);
		if (!record$1(value) || Object.keys(value).length !== 4 || value.accountId !== expected.accountId || value.chatId !== expected.chatId || typeof value.destinationId !== "string" || !UUID.test(value.destinationId) || typeof value.generation !== "string" || !UUID.test(value.generation)) fail("Chat binding is invalid; existing exports cannot be adopted.");
		await directory(join(path, "generations"), true);
		return {
			directory: path,
			binding: {
				accountId: expected.accountId,
				chatId: expected.chatId,
				destinationId: value.destinationId,
				generation: value.generation
			}
		};
	}
	async function current(path, binding) {
		await directory(path);
		await directory(join(path, "generations"));
		const raw = await text(join(path, "CURRENT"), 128);
		if (raw === null) return {
			pointer: null,
			markdown: null,
			metadata: null,
			chat: null,
			hash: null
		};
		const pointer = raw.trim();
		if (!UUID.test(pointer) || raw !== `${pointer}\n`) fail("CURRENT is invalid; only owned generation identifiers are accepted.");
		const target = join(path, "generations", pointer);
		await directory(target);
		const markdown = await text(join(target, "transcript.md")), metadata = await text(join(target, "sync.json"));
		if (markdown === null || metadata === null) fail("Current generation is incomplete; use Recover.");
		return {
			pointer,
			markdown,
			metadata,
			chat: decode(metadata, binding),
			hash: pairHash(pointer, markdown, metadata)
		};
	}
	async function files(chat, source, allowStaged = true, retained = null) {
		await directory(staging);
		if (source) await directory(source);
		const descriptors = /* @__PURE__ */ new Map(), bytes = /* @__PURE__ */ new Map();
		const required = new Set(retained?.messages.flatMap((message) => message.attachments.flatMap(({ attachment }) => attachment.state === "saved" || attachment.state === "opaque" ? [attachment.relativePath] : [])) ?? []);
		let total = 0;
		for (const message of chat.messages) for (const { attachment } of message.attachments) {
			if (attachment.state !== "saved" && attachment.state !== "opaque") continue;
			const key = LEAF.exec(attachment.relativePath)?.[1];
			if (!key) fail("Local attachments must use a SHA-256 leaf filename.");
			if (descriptors.has(attachment.relativePath)) continue;
			const prior = source ? await read(join(source, attachment.relativePath), FILE_LIMIT) : null;
			if (required.has(attachment.relativePath) && prior === null) fail("A retained attachment is missing from the current generation.");
			const data = prior ?? (allowStaged ? await read(join(staging, key), FILE_LIMIT) : null);
			if (data === null || digest(data) !== key) fail("Referenced attachment bytes are missing or corrupt; no export was published.");
			const descriptor = mediaDescriptor(key, attachment.name, attachment.mediaType, data.byteLength);
			if (descriptor.relativePath !== attachment.relativePath) fail("Attachment filename does not match its media descriptor.");
			total += data.byteLength;
			if (descriptors.size >= 128 || total > TOTAL_LIMIT) fail("Generation exceeds 128 attachments or 32 MiB.");
			descriptors.set(descriptor.relativePath, descriptor);
			bytes.set(descriptor.relativePath, data);
		}
		return {
			descriptors: [...descriptors.values()],
			bytes
		};
	}
	async function pending(path, binding) {
		const raw = await text(join(path, "pending.json"));
		if (raw === null) return null;
		const value = JSON.parse(raw);
		if (!record$1(value) || Object.keys(value).length !== 6 || !(value.beforeCurrent === null || typeof value.beforeCurrent === "string" && UUID.test(value.beforeCurrent)) || !(value.beforeHash === null || typeof value.beforeHash === "string" && /^[0-9a-f]{64}$/.test(value.beforeHash)) || value.beforeCurrent === null !== (value.beforeHash === null) || typeof value.target !== "string" || !UUID.test(value.target) || typeof value.markdown !== "string" || typeof value.metadata !== "string" || !Array.isArray(value.files) || value.files.length > 128) fail("Pending save is invalid; preserve it for manual recovery.");
		const descriptors = [];
		for (const entry of value.files) {
			if (!record$1(entry) || Object.keys(entry).length !== 5 || typeof entry.key !== "string" || typeof entry.name !== "string" || !(entry.mediaType === null || typeof entry.mediaType === "string") || typeof entry.size !== "number") fail("Pending attachment descriptor is invalid.");
			const descriptor = mediaDescriptor(entry.key, entry.name, entry.mediaType, entry.size);
			if (descriptor.relativePath !== entry.relativePath || descriptor.name !== entry.name || descriptor.mediaType !== entry.mediaType) fail("Pending attachment descriptor changed.");
			descriptors.push(descriptor);
		}
		const result = {
			beforeCurrent: value.beforeCurrent,
			beforeHash: value.beforeHash,
			target: value.target,
			markdown: value.markdown,
			metadata: value.metadata,
			files: descriptors
		};
		verifyPair(result, binding);
		return result;
	}
	async function publish(snapshot, journal) {
		const { directory: path, binding } = snapshot, target = join(path, "generations", journal.target);
		const present = await current(path, binding);
		if (present.pointer === journal.target) {
			if (present.markdown !== journal.markdown || present.metadata !== journal.metadata) fail("Published generation was edited; recovery preserved the pending save.");
		} else {
			if (present.pointer !== journal.beforeCurrent || present.hash !== journal.beforeHash) fail("Export changed since collection; preserve local edits and pending save.");
			const chat = verifyPair(journal, binding), source = present.pointer ? join(path, "generations", present.pointer) : null;
			if (present.chat) await files(present.chat, source, false);
			const media = await files(chat, source, true, present.chat);
			if (JSON.stringify(media.descriptors) !== JSON.stringify(journal.files)) fail("Pending attachment manifest changed.");
			await directory(target, true);
			for (const [name, bytes] of media.bytes) await immutable(join(target, name), bytes);
			await immutable(join(target, "transcript.md"), journal.markdown);
			await immutable(join(target, "sync.json"), journal.metadata);
			await syncDirectory(target);
			await syncDirectory(join(path, "generations"));
			await files(chat, target, false);
			await hooks.checkpoint?.("generation");
			const latest = await current(path, binding);
			if (latest.pointer !== journal.beforeCurrent || latest.hash !== journal.beforeHash) fail("Export changed before publication; preserve local edits and pending save.");
			if (latest.chat) await files(latest.chat, source, false);
			if (await text(join(target, "transcript.md")) !== journal.markdown || await text(join(target, "sync.json")) !== journal.metadata) fail("Prepared generation changed before publication; preserve the pending save.");
			await files(chat, target, false);
			await atomic(join(path, "CURRENT"), `${journal.target}\n`);
			await hooks.checkpoint?.("published");
		}
		const committed = await current(path, binding);
		if (committed.pointer !== journal.target || committed.markdown !== journal.markdown || committed.metadata !== journal.metadata) fail("Published generation changed; preserve the pending save.");
		const verified = await files(verifyPair(journal, binding), target, false);
		if (JSON.stringify(verified.descriptors) !== JSON.stringify(journal.files)) fail("Published attachment manifest changed.");
		await unlink(join(path, "pending.json"));
		await syncDirectory(path);
		snapshots.delete(binding.accountId + "\0" + binding.chatId);
		return {
			status: "partial",
			folder: target
		};
	}
	return {
		preflight: (expected) => run(async () => {
			const info = await bound(expected);
			if (await text(join(info.directory, "pending.json")) !== null) fail("A pending local save exists. Use Recover before collecting more messages.");
			const saved = await current(info.directory, info.binding);
			if (!saved.pointer && (await readdir(join(info.directory, "generations"))).length) fail("CURRENT is missing from an existing export; preserve generations for manual recovery.");
			const checked = downloadPass({
				prefix: "",
				markdown: saved.markdown,
				chat: saved.chat,
				binding: info.binding,
				chatKey: identity(expected),
				displayName: expected.name,
				observed: [],
				order: "verified",
				contiguous: false,
				requestedScope: "visible",
				stopReason: saved.chat?.coverage.stopReason ?? "rendered-window"
			});
			if (checked.phase === "paused") fail(`Local transcript conflict: ${checked.reason}.`);
			if (saved.chat) await files(saved.chat, saved.pointer ? join(info.directory, "generations", saved.pointer) : null, false);
			snapshots.set(expected.accountId + "\0" + expected.chatId, {
				...info,
				current: saved
			});
			return {
				chat: saved.chat ? checked.chat : null,
				markdown: saved.markdown,
				skipIds: new Set(checked.chat?.tombstones.map((item) => item.messageId) ?? []),
				knownAttachments: new Map(checked.chat?.messages.map((message) => [message.id, message.attachments]) ?? [])
			};
		}),
		stash: (bytes, name, mime) => run(async () => {
			if (bytes.byteLength > FILE_LIMIT) fail("Attachment exceeds 8 MiB.");
			await directory(staging);
			const owned = new Uint8Array(bytes), descriptor = mediaDescriptor(digest(owned), name, mime, owned.byteLength);
			const entries = await readdir(staging);
			let stagedSize = 0;
			if (entries.length > 4096) fail("Attachment staging exceeds 4096 files; preserve pending saves before manual cleanup.");
			for (const entry of entries) {
				if (!/^[0-9a-f]{64}$/.test(entry) && !/^\.writing-[0-9a-f-]{36}$/.test(entry)) fail("Attachment staging contains unknown files; preserve them for manual review.");
				const stat = await lstat(join(staging, entry));
				if (!stat.isFile() || stat.isSymbolicLink() || stat.size > FILE_LIMIT) fail("Attachment staging contains an invalid file.");
				stagedSize += stat.size;
			}
			if (stagedSize + (entries.includes(descriptor.key) ? 0 : owned.byteLength) > 67108864 || entries.length === 4096 && !entries.includes(descriptor.key)) fail("Attachment staging exceeds 64 MiB or 4096 files; preserve pending saves before manual cleanup.");
			await immutable(join(staging, descriptor.key), owned);
			return descriptor.mediaType === null ? {
				state: "opaque",
				name: descriptor.name,
				mediaType: null,
				relativePath: descriptor.relativePath
			} : {
				state: "saved",
				name: descriptor.name,
				mediaType: descriptor.mediaType,
				relativePath: descriptor.relativePath
			};
		}),
		commit: (expected, collected) => run(async () => {
			if (identity(expected) !== identity(collected.chat)) fail("Account or chat changed during collection.");
			const snapshot = snapshots.get(expected.accountId + "\0" + expected.chatId);
			if (!snapshot) fail("Run preflight before collecting messages.");
			const info = await bound(expected);
			if (JSON.stringify(info.binding) !== JSON.stringify(snapshot.binding)) fail("Export binding changed since preflight; existing state was preserved.");
			if (await pending(snapshot.directory, snapshot.binding)) fail("A pending local save exists. Use Recover.");
			const now = await current(snapshot.directory, snapshot.binding);
			if (now.pointer !== snapshot.current.pointer || now.hash !== snapshot.current.hash) fail("Export changed since preflight; preserve local edits and collect again.");
			const result = downloadPass({
				prefix: "",
				markdown: now.markdown,
				chat: now.chat,
				binding: snapshot.binding,
				chatKey: identity(expected),
				displayName: expected.name,
				observed: collected.messages,
				order: collected.order,
				contiguous: collected.contiguous,
				requestedScope: "visible",
				stopReason: collected.stopReason || "rendered-window"
			});
			if (result.phase === "paused" || !result.chat || result.markdown === null || result.metadata === null) fail(`Export paused: ${result.reason}.`);
			const source = now.pointer ? join(snapshot.directory, "generations", now.pointer) : null;
			if (now.chat) await files(now.chat, source, false);
			const media = await files(result.chat, source, true, now.chat);
			if (result.phase === "unchanged") {
				await files(result.chat, source, false);
				return {
					status: "unchanged (partial rendered scope)",
					folder: source ?? snapshot.directory
				};
			}
			const journal = {
				beforeCurrent: now.pointer,
				beforeHash: now.hash,
				target: randomUUID(),
				markdown: result.markdown,
				metadata: result.metadata,
				files: media.descriptors
			};
			verifyPair(journal, snapshot.binding);
			const serialized = `${JSON.stringify(journal)}\n`;
			if (Buffer.byteLength(serialized) > TEXT_LIMIT) fail("Pending save exceeds its 256 KiB durable journal limit.");
			await atomic(join(snapshot.directory, "pending.json"), serialized);
			await hooks.checkpoint?.("journal");
			return publish(snapshot, journal);
		}),
		recover: (expected) => run(async () => {
			const info = await bound(expected), journal = await pending(info.directory, info.binding);
			if (!journal) {
				const saved = await current(info.directory, info.binding);
				if (!saved.pointer || !saved.chat) fail("No pending local save exists for this chat.");
				const folder = join(info.directory, "generations", saved.pointer);
				await files(saved.chat, folder, false);
				return {
					status: "unchanged (partial rendered scope)",
					folder
				};
			}
			return publish({
				...info,
				current: await current(info.directory, info.binding)
			}, journal);
		}),
		folder: (expected) => run(async () => {
			if (!expected) return root;
			const info = await bound(expected), saved = await current(info.directory, info.binding);
			return saved.pointer ? join(info.directory, "generations", saved.pointer) : info.directory;
		}),
		close: () => closing ??= run(async () => {
			const stat = await lstat(lock);
			if (stat.dev !== lockStat.dev || stat.ino !== lockStat.ino || await text(join(lock, "owner"), 128) !== owner) fail("Output lock ownership changed; the foreign lock was preserved.");
			await unlink(join(lock, "owner"));
			await rmdir(lock);
			await syncDirectory(root);
			closed = true;
		})
	};
}
//#endregion
//#region local/main.ts
var execute = promisify(execFile);
var appDirectory = join(homedir(), "Library", "Application Support", "wa-scribe");
var profile = join(appDirectory, "chromium");
var configPath = join(appDirectory, "local.json");
var binaryDirectory = dirname(fileURLToPath(import.meta.url));
var record = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
var errorText = (error) => error instanceof Error ? error.message : "The local operation failed.";
var label = (value) => typeof value === "string" && value.length > 0 && value.length <= 256 && !/[\x00-\x1f\x7f-\x9f]/u.test(value);
var jid = (value) => typeof value === "string" && /^\d+(?:-\d+)?(?::\d+)?@(?:c\.us|g\.us|lid|s\.whatsapp\.net)$/.test(value) && value.length <= 256;
function chatKey(accountId, chatId) {
	return createHash("sha256").update(JSON.stringify([accountId, chatId])).digest("hex").slice(0, 16);
}
function chatRecord(value) {
	return record(value) && jid(value.accountId) && jid(value.chatId) && label(value.name) && typeof value.key === "string" && value.key === chatKey(value.accountId, value.chatId) && Array.isArray(value.aliases) && value.aliases.length <= 6 && value.aliases.every(label) && typeof value.selected === "boolean" && typeof value.result === "string";
}
async function start() {
	if (process.platform !== "darwin") throw new Error("This prototype launcher targets macOS.");
	const arguments_ = process.argv.slice(2);
	if (arguments_.length && (arguments_.length !== 2 || arguments_[0] !== "--output" || !arguments_[1])) throw new Error("Usage: wa-scribe [--output /absolute/export/folder]");
	await mkdir(appDirectory, {
		recursive: true,
		mode: 448
	});
	let output = join(homedir(), "Documents", "wa-scribe"), registered = [];
	try {
		const value = JSON.parse(await readFile(configPath, "utf8"));
		if (!record(value) || value.schema !== 1 || typeof value.output !== "string" || !Array.isArray(value.chats) || value.chats.length > 100 || !value.chats.every(chatRecord)) throw new Error("Local settings are invalid. Preserve the profile and export files for recovery.");
		output = value.output;
		registered = value.chats;
	} catch (error) {
		if (!(record(error) && error.code === "ENOENT")) throw error;
	}
	output = resolve(arguments_[1] ?? output);
	const canonicalApp = await realpath(appDirectory);
	const separateOutput = async (candidate) => {
		await mkdir(resolve(candidate), { recursive: true });
		const path = await realpath(resolve(candidate));
		if (path === canonicalApp || path.startsWith(canonicalApp + sep) || canonicalApp.startsWith(path + sep)) throw new Error("Choose an export folder separate from the browser profile and local settings.");
		return path;
	};
	output = await separateOutput(output);
	let startingStore, startingBrowser;
	let interruptedStartup = false;
	const stopStartup = () => {
		interruptedStartup = true;
		(async () => {
			const browser = await startingBrowser?.catch(() => null);
			try {
				await browser?.close();
			} finally {
				await (await startingStore?.catch(() => null))?.close();
			}
		})().catch((cause) => {
			console.error(errorText(cause));
			process.exitCode = 1;
		});
	};
	for (const signal of ["SIGINT", "SIGTERM"]) process.on(signal, stopStartup);
	let store, context;
	try {
		startingStore = createStore(output);
		store = await startingStore;
		if (interruptedStartup) {
			await store.close();
			return;
		}
		startingBrowser = chromium.launchPersistentContext(profile, {
			headless: false,
			acceptDownloads: true,
			viewport: {
				width: 1200,
				height: 850
			}
		});
		context = await startingBrowser;
		if (interruptedStartup) {
			await context.close();
			await store.close();
			return;
		}
	} catch (cause) {
		await (await startingStore?.catch(() => null))?.close();
		throw cause;
	} finally {
		for (const signal of ["SIGINT", "SIGTERM"]) process.removeListener(signal, stopStartup);
	}
	let available = [], loggedIn = false, running = false, busy = false, shuttingDown = false;
	let error = null, progress = "Link WhatsApp in its browser tab, then Refresh chats.";
	let controller = null, job = null;
	let actionDone = Promise.resolve();
	const lifetime = new AbortController();
	const persist = async () => {
		const temporary = join(appDirectory, `.settings-${randomUUID()}`), handle = await open(temporary, "wx", 384);
		try {
			await handle.writeFile(JSON.stringify({
				schema: 1,
				output,
				chats: registered
			}));
			await handle.sync();
		} finally {
			await handle.close();
		}
		await rename(temporary, configPath);
	};
	const chats = () => [...registered.map((chat) => {
		const cached = available.find((item) => item.key === chat.key);
		return cached && cached.name !== cached.chatId ? {
			...chat,
			name: cached.name,
			aliases: cached.aliases
		} : chat;
	}), ...available.filter((item) => !registered.some((known) => known.key === item.key))];
	const state = () => ({
		running: running || busy,
		output,
		loggedIn,
		chats: chats(),
		error,
		progress
	});
	const shutdown = async () => {
		if (shuttingDown) return;
		shuttingDown = true;
		controller?.abort();
		lifetime.abort();
		try {
			await context.close();
			await actionDone;
			await job;
		} finally {
			await store.close();
		}
	};
	const close = () => {
		shutdown().catch((cause) => {
			console.error(errorText(cause));
			process.exitCode = 1;
		});
	};
	context.on("close", close);
	for (const signal of ["SIGINT", "SIGTERM"]) process.on(signal, close);
	try {
		context.setDefaultTimeout(15e3);
		await context.addInitScript({ path: join(binaryDirectory, "page.js") });
		const panel = context.pages()[0] ?? await context.newPage(), whatsapp = await context.newPage();
		const panelUrl = pathToFileURL(join(binaryDirectory, "panel.html")).href;
		const account = async () => {
			if (whatsapp.isClosed() || !whatsapp.url().startsWith("https://web.whatsapp.com/")) return null;
			return whatsapp.evaluate(() => document.querySelector("#pane-side") ? window.waScribeLocal?.account() ?? null : null);
		};
		const remember = async (source) => {
			const previous = registered.find((item) => item.key === source.key);
			if (previous) Object.assign(previous, source);
			else {
				if (registered.length >= 100) throw new Error("This prototype supports 100 registered chats.");
				registered.push(source);
			}
			await persist();
		};
		const restoreStatuses = async () => {
			for (const chat of registered) try {
				chat.result = (await store.preflight(chat)).chat ? "Saved locally; start Sync explicitly." : "Not synced to this folder.";
			} catch (cause) {
				chat.result = errorText(cause);
			}
		};
		await restoreStatuses();
		const sync = async (targets) => {
			const currentStore = store;
			try {
				for (const target of targets) {
					if (controller?.signal.aborted) break;
					progress = `Opening ${target.name}`;
					try {
						const before = await currentStore.preflight(target);
						const names = [target.name, ...target.aliases].filter((hint) => !chats().some((other) => other.accountId === target.accountId && other.chatId !== target.chatId && [other.name, ...other.aliases].includes(hint)));
						const current = await inspectPage(whatsapp);
						if (!(current.ok && current.chat.accountId === target.accountId && current.chat.chatId === target.chatId) && !names.length) throw new Error("This chat's sidebar label is ambiguous. Its identity was preserved.");
						const opened = await openChat(whatsapp, {
							...target,
							name: names[0] ?? target.name,
							aliases: names.slice(1)
						}, controller?.signal);
						progress = `Saving ${opened.name}`;
						const observed = await capturePass(whatsapp, opened, {
							limit: 50,
							scope: "visible",
							...controller ? { signal: controller.signal } : {},
							skipMediaIds: before.skipIds,
							knownAttachments: before.knownAttachments,
							onProgress: (count) => {
								progress = `${opened.name}: ${count} rendered messages`;
							}
						}, currentStore.stash);
						if (controller?.signal.aborted) throw new Error("Stopped before saving. Start Sync explicitly when ready.");
						const saved = await currentStore.commit(target, observed);
						if (label(opened.name)) target.name = opened.name;
						const files = observed.messages.flatMap((message) => message.attachments);
						target.result = `${saved.status}; ${observed.messages.length} messages observed; ${files.filter((item) => item.attachment.state === "saved" || item.attachment.state === "opaque").length} files observed saved`;
					} catch (cause) {
						target.result = errorText(cause);
					}
					await remember(target);
				}
			} catch (cause) {
				error = errorText(cause);
			} finally {
				progress = controller?.signal.aborted ? "Sync stopped. Start again explicitly when ready." : "Finished. Review each chat's partial coverage and file results.";
				running = false;
				controller = null;
			}
		};
		await panel.exposeBinding("waScribe", async (source, request) => {
			if (source.page !== panel || source.frame !== panel.mainFrame() || source.frame.url() !== panelUrl) throw new Error("This local action is only available from the wa-scribe panel.");
			let ownsBusy = false, release;
			try {
				if (shuttingDown) throw new Error("The local app is closing.");
				if (!record(request) || typeof request.action !== "string") throw new Error("Invalid local action.");
				if (request.action === "state") {
					loggedIn = await account() !== null;
					return {
						ok: true,
						state: state()
					};
				}
				if (request.action === "stop") {
					controller?.abort();
					progress = "Stopping at the next safe boundary.";
					return {
						ok: true,
						state: state()
					};
				}
				if (running || busy) throw new Error("An operation is running. Use Stop and wait before another action.");
				busy = true;
				ownsBusy = true;
				error = null;
				actionDone = new Promise((resolve) => {
					release = resolve;
				});
				if (request.action === "list") {
					const id = await account();
					if (!id) throw new Error("Link WhatsApp using its QR code, then Refresh chats.");
					const result = await listChats(whatsapp);
					if (!result.ok) throw new Error(result.reason);
					if (await account() !== id) throw new Error("WhatsApp's account changed while listing chats.");
					if (!Array.isArray(result.chats) || result.chats.length > 5e3) throw new Error("The local chat list exceeds its supported size.");
					const discovered = result.chats.map((chat) => ({
						...chat,
						accountId: id,
						key: chatKey(id, chat.chatId),
						selected: false,
						result: "Not synced"
					}));
					if (!discovered.every(chatRecord)) throw new Error("The local chat list contains unsupported identity or label data.");
					available = discovered;
					const current = await inspectPage(whatsapp);
					if (current.ok && current.chat.accountId === id) {
						const entry = available.find((item) => item.chatId === current.chat.chatId);
						if (entry && label(current.chat.name)) entry.name = current.chat.name;
						else if (!entry && jid(current.chat.chatId) && label(current.chat.name)) available.push({
							...current.chat,
							key: chatKey(id, current.chat.chatId),
							aliases: [],
							selected: false,
							result: "Not synced"
						});
					}
					loggedIn = true;
					progress = `${available.length} chats in this browser's local cache.`;
				} else if (request.action === "sync") {
					if (!Array.isArray(request.keys) || !request.keys.length || request.keys.length > 100 || !request.keys.every((key) => typeof key === "string")) throw new Error("Select between 1 and 100 chats.");
					const keys = new Set(request.keys), targets = chats().filter((chat) => keys.has(chat.key)).map((chat) => ({
						...chat,
						selected: true
					}));
					if (targets.length !== keys.size) throw new Error("The chat list changed. Refresh and select again.");
					if (registered.length + targets.filter((chat) => !registered.some((prior) => prior.key === chat.key)).length > 100) throw new Error("This prototype supports 100 registered chats.");
					for (const chat of registered) chat.selected = keys.has(chat.key);
					for (const target of targets) await remember(target);
					if (shuttingDown) throw new Error("The local app is closing.");
					controller = new AbortController();
					running = true;
					job = sync(targets);
				} else if (request.action === "recover") {
					const target = registered.find((chat) => chat.key === request.key);
					if (!target) throw new Error("No registered chat was selected.");
					target.result = (await store.recover(target)).status;
					await persist();
				} else if (request.action === "open-folder") {
					const target = request.key === void 0 ? void 0 : registered.find((chat) => chat.key === request.key);
					if (request.key !== void 0 && !target) throw new Error("Sync this chat before opening its export folder.");
					await execute("/usr/bin/open", [await store.folder(target)], { signal: lifetime.signal });
				} else if (request.action === "choose-folder") {
					let chosen;
					try {
						chosen = (await execute("/usr/bin/osascript", ["-e", "POSIX path of (choose folder with prompt \"Choose the wa-scribe export folder\")"], { signal: lifetime.signal })).stdout.trim();
					} catch (cause) {
						if (record(cause) && typeof cause.stderr === "string" && cause.stderr.includes("(-128)")) return {
							ok: true,
							state: {
								...state(),
								running: false
							}
						};
						throw cause;
					}
					if (shuttingDown) throw new Error("The local app is closing.");
					const nextOutput = await separateOutput(chosen);
					if (nextOutput !== output) {
						const next = await createStore(nextOutput);
						try {
							await store.close();
						} catch (cause) {
							await next.close();
							throw cause;
						}
						store = next;
						output = nextOutput;
						await restoreStatuses();
						await persist();
					}
				} else throw new Error("Unknown local action.");
				return {
					ok: true,
					state: {
						...state(),
						running
					}
				};
			} catch (cause) {
				error = errorText(cause);
				return {
					ok: false,
					error,
					state: {
						...state(),
						running
					}
				};
			} finally {
				if (ownsBusy) {
					busy = false;
					release?.();
				}
			}
		});
		await panel.goto(panelUrl);
		try {
			await whatsapp.goto("https://web.whatsapp.com/", {
				waitUntil: "domcontentloaded",
				timeout: 3e4
			});
		} catch {
			error = "WhatsApp could not load. Reload its browser tab when the connection is available.";
		}
		if (shuttingDown) return;
		if (await account()) await panel.bringToFront();
		console.log("wa-scribe local prototype is open. Exports stay on this Mac. Close Chromium or press Control-C to quit.");
	} catch (cause) {
		await shutdown();
		throw cause;
	}
}
start().catch((cause) => {
	console.error(errorText(cause));
	process.exitCode = 1;
});
//#endregion
