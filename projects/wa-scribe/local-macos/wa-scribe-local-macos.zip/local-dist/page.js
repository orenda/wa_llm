(function() {
	//#region src/local-identity.ts
	var DATABASE$2 = "model-storage";
	var MAX_KEYS = 1e5;
	var MAX_KEY_LENGTH = 4096;
	var MAX_KEY_BYTES = 4194304;
	var TIMEOUT_MS$2 = 5e3;
	var OPAQUE_ID = /^(?:[0-9a-f]{20}|[0-9a-f]{32})$/i;
	var MESSAGE_KEY$1 = /^(true|false)_([^_\s]+)_([^_\s]+)(?:_(\d+(?::\d+)?@(?:c\.us|lid|s\.whatsapp\.net)))?$/;
	var CHAT_JID$1 = /^\d+(?:-\d+)?(?::\d+)?@(?:c\.us|g\.us|lid|s\.whatsapp\.net)$/;
	var failure$2 = (reason) => ({
		ok: false,
		reason
	});
	function validIds(rawIds) {
		return rawIds.length > 0 && rawIds.length <= 500 && new Set(rawIds).size === rawIds.length && rawIds.every((id) => typeof id === "string" && OPAQUE_ID.test(id));
	}
	/** Resolve only after seeing the entire bounded keyspace; another chat can reuse an opaque ID. */
	function resolveMessageKeyList(rawIds, keys) {
		if (!validIds(rawIds)) return failure$2("The rendered message IDs are unsupported or repeated.");
		if (keys.length > MAX_KEYS) return failure$2("The local message keyspace exceeds the supported identity limit.");
		const requested = new Set(rawIds), matches = /* @__PURE__ */ new Map(), encoder = new TextEncoder();
		let keyBytes = 0;
		for (const key of keys) {
			if (typeof key !== "string") return failure$2("The local message key format is unsupported.");
			if (key.length > MAX_KEY_LENGTH) return failure$2("A local message key exceeds the supported identity limit.");
			keyBytes += encoder.encode(key).byteLength;
			if (keyBytes > MAX_KEY_BYTES) return failure$2("The local message keys exceed the supported identity byte limit.");
			const match = MESSAGE_KEY$1.exec(key);
			if (!match?.[2] || !match[3]) {
				if (rawIds.some((id) => key.includes(id))) return failure$2("A rendered message ID appears in an unsupported local message key.");
				continue;
			}
			const rawId = match[3];
			if (!requested.has(rawId)) continue;
			if (matches.has(rawId)) return failure$2("A rendered message ID matches multiple local message keys.");
			matches.set(rawId, {
				id: key,
				chatId: match[2],
				outgoing: match[1] === "true",
				senderId: match[4] ?? null
			});
		}
		if (matches.size !== rawIds.length) return failure$2("Some rendered messages have no supported local message key.");
		const chats = new Set([...matches.values()].map((key) => key.chatId));
		if (chats.size !== 1 || [...chats].some((id) => !CHAT_JID$1.test(id))) return failure$2("The rendered messages do not identify one supported conversation.");
		return {
			ok: true,
			keys: matches
		};
	}
	/** Inspect primary keys only, in one readonly transaction; never read message records. */
	async function resolveLocalMessageKeys(rawIds, signal) {
		if (!validIds(rawIds)) return failure$2("The rendered message IDs are unsupported or repeated.");
		if (signal?.aborted) return failure$2("Local message identity lookup was stopped.");
		const requested = [...rawIds], deadline = Date.now() + TIMEOUT_MS$2;
		return new Promise((resolve) => {
			let settled = false, database, transaction;
			const finish = (result) => {
				if (settled) return;
				settled = true;
				clearTimeout(timer);
				signal?.removeEventListener("abort", abort);
				try {
					transaction?.abort();
				} catch {}
				database?.close();
				resolve(result.ok && Date.now() >= deadline ? failure$2("Local message identity lookup timed out.") : result);
			};
			const abort = () => finish(failure$2("Local message identity lookup was stopped."));
			const timer = setTimeout(() => finish(failure$2("Local message identity lookup timed out.")), TIMEOUT_MS$2);
			signal?.addEventListener("abort", abort, { once: true });
			if (signal?.aborted) {
				abort();
				return;
			}
			(async () => {
				try {
					const existing = (await indexedDB.databases()).filter((info) => info.name === DATABASE$2);
					if (settled) return;
					if (existing.length !== 1) {
						finish(failure$2("The local message database is not ready. Wait for WhatsApp to finish loading and retry."));
						return;
					}
					const opening = indexedDB.open(DATABASE$2);
					opening.onupgradeneeded = () => {
						opening.transaction?.abort();
						finish(failure$2("The local message database changed; no upgrade was performed."));
					};
					opening.onblocked = () => finish(failure$2("The local message database is temporarily blocked."));
					opening.onerror = () => finish(failure$2("The local message database could not be opened."));
					opening.onsuccess = () => {
						const opened = opening.result;
						if (settled) {
							opened.close();
							return;
						}
						database = opened;
						opened.onversionchange = () => finish(failure$2("The local message database changed during identity lookup."));
						try {
							if (!opened.objectStoreNames.contains("message")) {
								finish(failure$2("The local message database schema is unsupported."));
								return;
							}
							const reading = opened.transaction("message", "readonly");
							transaction = reading;
							reading.onabort = () => finish(failure$2("The local message key snapshot was interrupted."));
							reading.onerror = () => finish(failure$2("The local message keys could not be read."));
							const store = reading.objectStore("message");
							if (store.keyPath !== "id") {
								finish(failure$2("The local message database schema is unsupported."));
								return;
							}
							let count, keys;
							const counting = store.count(), listing = store.getAllKeys(void 0, 100001);
							counting.onsuccess = () => {
								count = counting.result;
							};
							listing.onsuccess = () => {
								keys = listing.result;
							};
							reading.oncomplete = () => {
								transaction = void 0;
								if (count === void 0 || keys === void 0 || count !== keys.length || count > MAX_KEYS) {
									finish(failure$2("The complete local message keyspace exceeds the supported identity limit."));
									return;
								}
								finish(resolveMessageKeyList(requested, keys));
							};
						} catch {
							finish(failure$2("The local message keys could not be read."));
						}
					};
				} catch {
					finish(failure$2("The existing local message database could not be inspected."));
				}
			})();
		});
	}
	//#endregion
	//#region src/whatsapp.ts
	var MESSAGE_ID = /^(true|false)_([^_]+)_([^\s]+)$/;
	var JID = /^\d+(?:-\d+)?(?::\d+)?@(?:c\.us|g\.us|lid|s\.whatsapp\.net)$/;
	var ACCOUNT_JID = /^\d+(?::\d+)?@(?:c\.us|lid|s\.whatsapp\.net)$/;
	function accountId() {
		const identities = /* @__PURE__ */ new Set();
		for (const key of ["last-wid", "last-wid-md"]) try {
			const raw = localStorage.getItem(key);
			if (!raw) continue;
			const value = ACCOUNT_JID.test(raw) ? raw : JSON.parse(raw);
			const id = typeof value === "string" ? value : typeof value === "object" && value !== null && "_serialized" in value && typeof value._serialized === "string" ? value._serialized : null;
			if (id && ACCOUNT_JID.test(id)) identities.add(id.replace(/:\d+@/, "@").replace(/@s\.whatsapp\.net$/, "@c.us"));
		} catch {}
		return identities.size === 1 ? [...identities][0] ?? null : null;
	}
	function messageKey(row, resolved) {
		const id = row.getAttribute("data-id") ?? "";
		const local = resolved?.get(id);
		if (local) return local;
		const match = MESSAGE_ID.exec(id);
		if (!match?.[2] || !JID.test(match[2]) || !match[3]) return null;
		const sender = /_(\d+(?::\d+)?@(?:c\.us|lid|s\.whatsapp\.net))$/.exec(match[3]);
		return {
			id,
			chatId: match[2],
			outgoing: match[1] === "true",
			senderId: sender?.[1] ?? null
		};
	}
	function messageRows(main, resolved) {
		const seen = /* @__PURE__ */ new Set();
		return Array.from(main.querySelectorAll("[data-id]")).filter((row) => {
			const key = messageKey(row, resolved);
			if (row.closest("[data-testid='quoted-message']") || !key || seen.has(key.id)) return false;
			seen.add(key.id);
			return true;
		});
	}
	function idStructure(row) {
		const value = (row.getAttribute("data-id") ?? "").slice(0, 256);
		const separators = {
			"_": "underscore",
			"@": "at",
			".": "dot",
			":": "colon",
			"-": "dash",
			"/": "slash",
			"%": "percent",
			"{": "open-object",
			"}": "close-object",
			"[": "open-array",
			"]": "close-array",
			"\"": "quote",
			",": "comma",
			"\\": "backslash"
		};
		return {
			shape: Array.from(value, (char) => separators[char] ?? (/\s/u.test(char) ? "space" : "value")).filter((kind, index, kinds) => kind !== "value" || kinds[index - 1] !== "value").slice(0, 64),
			directionPrefix: /^(true|false)_/.test(value),
			whitespace: /\s/u.test(value),
			percentEncoding: /%[0-9a-f]{2}/i.test(value),
			knownJidMarkers: [
				"c.us",
				"g.us",
				"lid",
				"s.whatsapp.net"
			].filter((domain) => value.includes(`@${domain}`)),
			hasText: row.querySelector(".selectable-text") !== null,
			hasEnvelope: row.querySelector("[data-pre-plain-text]") !== null
		};
	}
	function identityDiagnostic(main, recognizedRows, conversationIds) {
		const candidates = Array.from(main.querySelectorAll("[data-id]"));
		const structures = /* @__PURE__ */ new Map();
		for (const row of candidates.slice(0, 64)) {
			if (row.closest("[data-testid='quoted-message']")) continue;
			const structure = idStructure(row), signature = JSON.stringify(structure), previous = structures.get(signature);
			if (previous) previous.count += 1;
			else if (structures.size < 6) structures.set(signature, {
				...structure,
				count: 1
			});
		}
		let quotedRows = 0, invalidShape = 0, unsupportedChatIds = 0;
		for (const row of candidates) {
			if (row.closest("[data-testid='quoted-message']")) {
				quotedRows += 1;
				continue;
			}
			const match = MESSAGE_ID.exec(row.getAttribute("data-id") ?? "");
			if (!match?.[2]) invalidShape += 1;
			else if (!JID.test(match[2])) unsupportedChatIds += 1;
		}
		return {
			dataIds: candidates.length,
			recognizedRows,
			quotedRows,
			invalidShape,
			unsupportedChatIds,
			conversationIds,
			messageBubbles: main.querySelectorAll(".message-in, .message-out").length,
			textEnvelopes: main.querySelectorAll("[data-pre-plain-text]").length,
			selectableTextNodes: main.querySelectorAll(".selectable-text").length,
			structures: [...structures.values()]
		};
	}
	function inspect(main, resolved) {
		if (!main || document.querySelectorAll("#main").length !== 1) return {
			ok: false,
			reason: "Open a WhatsApp conversation first."
		};
		const account = accountId();
		if (!account) return {
			ok: false,
			reason: "WhatsApp did not expose a verifiable account ID. Sign in and reload WhatsApp Web."
		};
		const rows = messageRows(main, resolved);
		const ids = new Set(rows.map((row) => messageKey(row, resolved)?.chatId).filter((id) => id !== void 0));
		if (ids.size !== 1) return {
			ok: false,
			reason: `${ids.size === 0 ? "No supported message-based conversation ID was found in the open chat." : "The open chat contains multiple message-based conversation IDs."} Identity diagnostic: ${JSON.stringify(identityDiagnostic(main, rows.length, ids.size))}`
		};
		const chatId = [...ids][0];
		if (!chatId) return {
			ok: false,
			reason: "No stable conversation ID is available."
		};
		const header = main.querySelector("header span[title], header [data-testid='conversation-info-header-chat-title']");
		return {
			ok: true,
			chat: {
				accountId: account,
				chatId,
				name: header?.getAttribute("title") || header?.textContent || chatId
			},
			rendered: rows.length
		};
	}
	function inspectWhatsApp() {
		return inspect(document.querySelector("#main"));
	}
	function rowSignature(main) {
		return JSON.stringify(Array.from(main.querySelectorAll("[data-id]"), (row) => row.getAttribute("data-id")));
	}
	function watchContext(main, freezeRows = false) {
		const account = accountId(), sidebar = document.querySelector("#pane-side");
		const selected = () => Array.from(document.querySelectorAll("#pane-side [aria-selected='true'], #pane-side [data-selected='true']"));
		const selection = selected();
		const originalIds = freezeRows ? rowSignature(main) : null;
		let changed = false;
		const observer = new MutationObserver(() => {
			changed = true;
		});
		if (sidebar) observer.observe(sidebar, {
			subtree: true,
			attributes: true,
			attributeFilter: ["aria-selected", "data-selected"]
		});
		return {
			current: () => {
				if (observer.takeRecords().length) changed = true;
				const current = selected();
				return !changed && document.querySelector("#main") === main && document.querySelectorAll("#main").length === 1 && document.querySelector("#pane-side") === sidebar && accountId() === account && current.length === selection.length && current.every((node, index) => node === selection[index]) && (originalIds === null || rowSignature(main) === originalIds);
			},
			close: () => observer.disconnect()
		};
	}
	async function resolveWindow(main, signal) {
		const context = watchContext(main, true);
		const keys = /* @__PURE__ */ new Map();
		try {
			const opaque = Array.from(main.querySelectorAll("[data-id]")).filter((row) => !row.closest("[data-testid='quoted-message']")).map((row) => row.getAttribute("data-id") ?? "").filter((id) => /^(?:[0-9a-f]{20}|[0-9a-f]{32})$/i.test(id));
			if (opaque.length) {
				const local = await resolveLocalMessageKeys(opaque, signal);
				if (!local.ok) return {
					ok: false,
					reason: local.reason
				};
				for (const [raw, key] of local.keys) keys.set(raw, key);
			}
			if (signal?.aborted || !context.current()) return {
				ok: false,
				reason: "The WhatsApp account, conversation or rendered messages changed during identity lookup. Try again with the chat left open."
			};
			const result = inspect(main, keys);
			return result.ok ? {
				...result,
				keys
			} : result;
		} finally {
			context.close();
		}
	}
	async function inspectWhatsAppResolved() {
		const main = document.querySelector("#main");
		if (!main || !accountId()) return inspectWhatsApp();
		const result = await resolveWindow(main);
		return result.ok ? {
			ok: true,
			chat: result.chat,
			rendered: result.rendered
		} : result;
	}
	function bodyText(node) {
		if (node.nodeType === Node.TEXT_NODE) return node.textContent ?? "";
		if (node instanceof HTMLBRElement) return "\n";
		if (node instanceof HTMLImageElement) return node.alt;
		const children = Array.from(node.childNodes).map(bodyText).join("");
		return node instanceof HTMLDivElement && node.nextSibling ? `${children}\n` : children;
	}
	function messageText(row) {
		const parts = Array.from(row.querySelectorAll(".selectable-text")).filter((node) => !node.parentElement?.closest(".selectable-text") && !node.closest("[data-testid='quoted-message']"));
		const quote = row.querySelector("[data-testid='quoted-message']");
		return [quote ? bodyText(quote).replace(/\r\n?/g, "\n").split("\n").map((line) => `> ${line}`).join("\n") : "", parts.map(bodyText).join("\n")].filter((part) => part !== "").join("\n\n").replace(/\r\n?/g, "\n");
	}
	function attachmentMarkers(row) {
		if (Array.from(row.querySelectorAll("[data-icon*='view-once'], [data-testid*='view-once']")).some((node) => !node.closest("[data-testid='quoted-message']"))) return [{
			slot: 1,
			attachment: {
				state: "unsupported",
				detail: "View-once content was not opened."
			}
		}];
		const media = Array.from(row.querySelectorAll("img:not(.emoji), video, audio, [data-testid='document-thumb'], [data-icon*='document']")).filter((node) => !node.closest("[data-testid='quoted-message'], [data-testid='avatar']"));
		if (!media.length) return [];
		return media.filter((node) => !media.some((parent) => parent !== node && parent.contains(node))).slice(0, 32).map((_, index) => ({
			slot: index + 1,
			attachment: {
				state: "unavailable",
				limitation: "This rendered attachment has no verified original bytes. It was not downloaded."
			}
		}));
	}
	async function readWindow(main, expected, signal) {
		const current = await resolveWindow(main, signal);
		if (!current.ok || document.querySelector("#main") !== main || current.chat.accountId !== expected.accountId || current.chat.chatId !== expected.chatId) throw new Error("The WhatsApp account or selected conversation changed. Collection stopped before mixing content.");
		const messages = [];
		const deletedIds = [];
		let limitation = null;
		for (const bubble of Array.from(main.querySelectorAll(".message-in, .message-out, [data-pre-plain-text]"))) {
			if (bubble.closest("[data-testid='quoted-message']")) continue;
			const keyed = bubble.closest("[data-id]") ?? bubble.querySelector("[data-id]");
			if (!keyed || !main.contains(keyed) || !messageKey(keyed, current.keys)) limitation = "unidentified-message";
		}
		for (const row of messageRows(main, current.keys)) {
			const key = messageKey(row, current.keys);
			if (!key || key.chatId !== expected.chatId) throw new Error("A rendered message belongs to another chat.");
			const pre = ((row.matches("[data-pre-plain-text]") ? [row] : Array.from(row.querySelectorAll("[data-pre-plain-text]"))).find((node) => !node.closest("[data-testid='quoted-message']"))?.getAttribute("data-pre-plain-text") ?? "").replace(/[\u200e\u200f\u202a-\u202e\u2066-\u2069]/gu, "").trim();
			const match = /^\[([^\]]+)\]\s*(.*):\s*$/su.exec(pre);
			const deleted = Array.from(row.querySelectorAll("[data-icon='recalled'], [data-icon='recalled-out'], [data-testid='recalled']")).some((node) => !node.closest("[data-testid='quoted-message']"));
			const text = messageText(row);
			const attachments = attachmentMarkers(row);
			if (!match && !deleted) limitation = "unsupported-message-envelope";
			if (!text && !attachments.length && !deleted) {
				limitation = "unloaded-message";
				continue;
			}
			if (deleted) {
				deletedIds.push(key.id);
				attachments.push({
					slot: attachments.length + 1,
					attachment: {
						state: "unavailable",
						limitation: "WhatsApp reports this message deleted; original content is unavailable."
					}
				});
			}
			messages.push({
				id: key.id,
				sender: {
					key: key.outgoing ? expected.accountId : key.senderId,
					name: match?.[2] || (key.outgoing ? "You" : "Unknown sender")
				},
				timestamp: {
					display: match?.[1] ?? "",
					precision: match ? "display-only" : "unknown",
					timeZone: null,
					instant: null
				},
				sequence: "verified",
				text,
				attachments,
				sourceBaseline: JSON.stringify({
					text,
					attachments,
					deleted
				})
			});
		}
		return {
			messages,
			deletedIds,
			limitation,
			binding: rowSignature(main)
		};
	}
	async function captureWindowMedia(main, expected, messages, deleted, capture, deadline, signal) {
		const context = watchContext(main, true);
		try {
			for (const message of messages) {
				if (Date.now() >= deadline) break;
				if (!message.attachments.length || deleted.includes(message.id)) continue;
				const current = await resolveWindow(main, signal);
				if (!current.ok || !context.current() || current.chat.accountId !== expected.accountId || current.chat.chatId !== expected.chatId) throw new Error("The source changed before attachment download.");
				const row = messageRows(main, current.keys).find((node) => messageKey(node, current.keys)?.id === message.id);
				if (!row || messageText(row) !== message.text) throw new Error("The attachment's message changed.");
				const verify = async () => {
					if (signal?.aborted || !context.current() || messageText(row) !== message.text) return false;
					const checked = await resolveWindow(main, signal);
					return !signal?.aborted && context.current() && messageText(row) === message.text && checked.ok && checked.chat.accountId === expected.accountId && checked.chat.chatId === expected.chatId && messageKey(row, checked.keys)?.id === message.id;
				};
				const attachments = await capture(row, message, verify);
				if (!await verify()) throw new Error("The source changed during attachment download.");
				message.attachments = attachments;
			}
		} finally {
			context.close();
		}
	}
	/** Join only when observed windows give one unambiguous ordering. */
	function joinWindows(saved, observed) {
		if (!saved.length) return observed;
		const existing = new Set(saved.map((message) => message.id));
		if (!observed.some((message) => existing.has(message.id))) return null;
		const previous = new Map(saved.map((message) => [message.id, message]));
		for (const message of observed) {
			const prior = previous.get(message.id);
			if (!prior || prior.sourceBaseline !== message.sourceBaseline) continue;
			message.attachments = message.attachments.map((entry) => {
				const kept = prior.attachments.find((item) => item.slot === entry.slot);
				return (entry.attachment.state === "pending" || entry.attachment.state === "unavailable") && kept && (kept.attachment.state === "saved" || kept.attachment.state === "opaque") ? kept : entry;
			});
		}
		const values = new Map([...saved, ...observed].map((message) => [message.id, message]));
		const edges = new Map([...values.keys()].map((id) => [id, /* @__PURE__ */ new Set()]));
		const degree = new Map([...values.keys()].map((id) => [id, 0]));
		for (const window of [saved, observed]) for (let index = 1; index < window.length; index += 1) {
			const before = window[index - 1]?.id, after = window[index]?.id;
			if (!before || !after || edges.get(before)?.has(after)) continue;
			edges.get(before)?.add(after);
			degree.set(after, (degree.get(after) ?? 0) + 1);
		}
		const result = [];
		while (degree.size) {
			const ready = [...degree].filter(([, count]) => count === 0);
			if (ready.length !== 1) return null;
			const id = ready[0]?.[0], message = id ? values.get(id) : void 0;
			if (!id || !message) return null;
			result.push(message);
			degree.delete(id);
			for (const after of edges.get(id) ?? []) degree.set(after, (degree.get(after) ?? 0) - 1);
		}
		return result;
	}
	function scrollContainer(main) {
		const sample = Array.from(main.querySelectorAll("[data-pre-plain-text]")).find((node) => !node.closest("[data-testid='quoted-message']")) ?? messageRows(main)[0];
		for (let node = sample?.parentElement; node && main.contains(node); node = node.parentElement) if (node.scrollHeight > node.clientHeight + 20 && /auto|scroll/.test(getComputedStyle(node).overflowY)) return node;
		return null;
	}
	function wait(ms, signal) {
		return new Promise((resolve) => {
			const finish = () => {
				clearTimeout(timer);
				signal?.removeEventListener("abort", finish);
				resolve();
			};
			const timer = setTimeout(finish, ms);
			signal?.addEventListener("abort", finish, { once: true });
			if (signal?.aborted) finish();
		});
	}
	async function collectWhatsApp(input) {
		const main = document.querySelector("#main");
		if (!main) throw new Error("Open the selected WhatsApp conversation first.");
		const limit = Number.isFinite(input.limit) ? Math.min(Math.max(Math.floor(input.limit), 1), 500) : 500;
		const deadline = Date.now() + (Number.isFinite(input.maxMs) ? Math.min(Math.max(input.maxMs, 1e3), 6e4) : 24e3);
		const scroller = scrollContainer(main), originalTop = scroller?.scrollTop;
		const context = watchContext(main);
		let messages = [], deletedIds = [], upperId = null;
		let verifiedRows = null;
		let stopReason = input.scope === "visible" ? "visible-window" : "history-boundary-unverified";
		let contiguous = true, idle = 0;
		try {
			while (true) {
				if (input.signal?.aborted) {
					stopReason = "stopped";
					break;
				}
				if (!context.current()) throw new Error("The selected WhatsApp conversation changed.");
				const window = await readWindow(main, input.expected, input.signal);
				if (!context.current()) throw new Error("The selected WhatsApp conversation changed.");
				verifiedRows = window.binding;
				if (upperId === null) upperId = window.messages.at(-1)?.id ?? null;
				const cutoff = window.messages.findIndex((message) => message.id === upperId);
				const observed = cutoff >= 0 ? window.messages.slice(0, cutoff + 1) : window.messages;
				const merged = joinWindows(messages, observed);
				if (!merged) {
					stopReason = "unverified-history-overlap";
					contiguous = false;
					break;
				}
				if (input.captureMedia) await captureWindowMedia(main, input.expected, observed.slice(-limit), window.deletedIds, input.captureMedia, deadline, input.signal);
				idle = merged.length === messages.length ? idle + 1 : 0;
				messages = merged;
				let bytes = 0;
				const bounded = [];
				for (const message of [...messages].reverse()) {
					bytes += new TextEncoder().encode(JSON.stringify(message)).byteLength;
					if (bytes > 131072) break;
					bounded.unshift(message);
				}
				const overBytes = bounded.length !== messages.length;
				if (overBytes) messages = bounded;
				deletedIds = [.../* @__PURE__ */ new Set([...deletedIds, ...window.deletedIds])];
				input.onProgress?.(messages.length);
				if (overBytes) {
					stopReason = "byte-budget";
					break;
				}
				if (window.limitation) {
					stopReason = window.limitation;
					contiguous = false;
					break;
				}
				if (messages.length >= limit) {
					messages = messages.slice(-limit);
					stopReason = "message-budget";
					break;
				}
				if (input.scope === "visible") break;
				if (Date.now() >= deadline) {
					stopReason = "time-budget";
					break;
				}
				if (!scroller) {
					stopReason = "history-scroll-unavailable";
					break;
				}
				if (idle >= 3) break;
				scroller.scrollTop = Math.max(0, scroller.scrollTop - Math.max(scroller.clientHeight * .7, 160));
				await wait(450, input.signal);
			}
		} finally {
			if (!input.signal?.aborted && scroller && originalTop !== void 0 && context.current() && rowSignature(main) === verifiedRows) scroller.scrollTop = originalTop;
			context.close();
		}
		const kept = new Set(messages.map((message) => message.id));
		return {
			chat: input.expected,
			messages,
			order: "verified",
			contiguous,
			stopReason,
			deletedIds: deletedIds.filter((id) => kept.has(id))
		};
	}
	//#endregion
	//#region src/chat-catalog.ts
	var DATABASE$1 = "model-storage";
	var CHAT_STORE = "chat";
	var CONTACT_STORE = "contact";
	var MAX_CHATS = 5e3;
	var MAX_LABEL = 256;
	var MAX_OUTPUT_BYTES = 1048576;
	var TIMEOUT_MS$1 = 5e3;
	var CHAT_JID = /^\d+(?:-\d+)?(?::\d+)?@(?:c\.us|g\.us|lid|s\.whatsapp\.net)$/;
	var failure$1 = (reason) => ({
		ok: false,
		reason
	});
	function objectRecord(value) {
		return typeof value === "object" && value !== null && !Array.isArray(value);
	}
	function ownString(record, field) {
		if (!Object.hasOwn(record, field)) return null;
		const value = record[field];
		if (typeof value !== "string" || value.length > MAX_LABEL || /[\u0000-\u001f\u007f-\u009f]/.test(value)) return null;
		const label = value.trim();
		return label.length > 0 && label.length <= MAX_LABEL ? label : null;
	}
	/** Read only identity and approved display labels; all other cloned record fields stay opaque. */
	function projectChatMetadata(primaryKey, value, contact) {
		if (typeof primaryKey !== "string" || primaryKey.length > MAX_LABEL || !CHAT_JID.test(primaryKey)) return null;
		if (!objectRecord(value) || value.id !== primaryKey) return null;
		const labels = [];
		for (const field of ["formattedTitle", "name"]) {
			const label = ownString(value, field);
			if (label !== null && !labels.includes(label)) labels.push(label);
		}
		if (objectRecord(contact) && contact.id === primaryKey) for (const field of [
			"name",
			"shortName",
			"pushname"
		]) {
			const label = ownString(contact, field);
			if (label !== null && !labels.includes(label)) labels.push(label);
		}
		const name = labels[0] ?? primaryKey;
		return {
			chatId: primaryKey,
			name,
			aliases: labels.filter((label) => label !== name).slice(0, 6)
		};
	}
	/** Enumerate the bounded local chat cache. This does not describe all chats on the account. */
	async function readLocalChatCatalog(signal) {
		if (signal?.aborted) return failure$1("Local chat catalog lookup was stopped.");
		const deadline = Date.now() + TIMEOUT_MS$1;
		return new Promise((resolve) => {
			let settled = false;
			let database;
			let transaction;
			const finish = (result) => {
				if (settled) return;
				settled = true;
				clearTimeout(timer);
				signal?.removeEventListener("abort", abort);
				try {
					transaction?.abort();
				} catch {}
				database?.close();
				resolve(result.ok && Date.now() >= deadline ? failure$1("Local chat catalog lookup timed out.") : result);
			};
			const abort = () => finish(failure$1("Local chat catalog lookup was stopped."));
			const timer = setTimeout(() => finish(failure$1("Local chat catalog lookup timed out.")), TIMEOUT_MS$1);
			signal?.addEventListener("abort", abort, { once: true });
			if (signal?.aborted) {
				abort();
				return;
			}
			(async () => {
				try {
					const existing = (await indexedDB.databases()).filter((info) => info.name === DATABASE$1);
					if (settled) return;
					if (existing.length !== 1) {
						finish(failure$1("The local chat database is not ready. Wait for WhatsApp to finish loading, then Refresh chats."));
						return;
					}
					const opening = indexedDB.open(DATABASE$1);
					opening.onupgradeneeded = () => {
						opening.transaction?.abort();
						finish(failure$1("The local chat database changed; no upgrade was performed."));
					};
					opening.onblocked = () => finish(failure$1("The local chat database is temporarily blocked."));
					opening.onerror = () => finish(failure$1("The local chat database could not be opened."));
					opening.onsuccess = () => {
						const opened = opening.result;
						if (settled) {
							opened.close();
							return;
						}
						database = opened;
						opened.onversionchange = () => finish(failure$1("The local chat database changed during catalog lookup."));
						try {
							if (!opened.objectStoreNames.contains(CHAT_STORE)) {
								finish(failure$1("The local chat database schema is unsupported."));
								return;
							}
							const hasContacts = opened.objectStoreNames.contains(CONTACT_STORE);
							const reading = opened.transaction(hasContacts ? [CHAT_STORE, CONTACT_STORE] : [CHAT_STORE], "readonly");
							transaction = reading;
							reading.onabort = () => finish(failure$1("The local chat catalog snapshot was interrupted."));
							reading.onerror = () => finish(failure$1("The local chat catalog could not be read."));
							const chats = reading.objectStore(CHAT_STORE);
							if (chats.keyPath !== "id") {
								finish(failure$1("The local chat database schema is unsupported."));
								return;
							}
							const contacts = hasContacts ? reading.objectStore(CONTACT_STORE) : void 0;
							const contactStore = contacts?.keyPath === "id" ? contacts : void 0;
							let count;
							let visited = 0;
							let failed = null;
							const output = [];
							let outputBytes = 2;
							const append = (chat) => {
								const encoded = new TextEncoder().encode(JSON.stringify(chat)).byteLength;
								const nextSize = outputBytes + encoded + (output.length === 0 ? 0 : 1);
								if (nextSize > MAX_OUTPUT_BYTES) {
									failed = "The local chat catalog exceeds the supported output size.";
									return;
								}
								output.push(chat);
								outputBytes = nextSize;
							};
							const counting = chats.count();
							counting.onsuccess = () => {
								count = counting.result;
								if (count > MAX_CHATS) failed = "The local chat catalog exceeds the supported entry limit.";
							};
							const cursorRequest = chats.openCursor();
							cursorRequest.onerror = () => {
								failed = "The local chat catalog could not be read.";
							};
							cursorRequest.onsuccess = () => {
								if (settled || failed !== null) return;
								const cursor = cursorRequest.result;
								if (cursor === null) return;
								visited += 1;
								if (visited > MAX_CHATS) {
									failed = "The local chat catalog exceeds the supported entry limit.";
									return;
								}
								const key = cursor.primaryKey;
								const value = cursor.value;
								const projected = projectChatMetadata(key, value);
								if (projected !== null) {
									if (contactStore !== void 0) {
										const request = contactStore.get(projected.chatId);
										request.onerror = () => {
											failed = "The local contact labels could not be read.";
										};
										request.onsuccess = () => {
											if (settled || failed !== null) return;
											const contact = request.result;
											const withContact = projectChatMetadata(key, value, contact);
											if (withContact !== null) append(withContact);
										};
									} else append(projected);
								}
								try {
									cursor.continue();
								} catch {
									failed = "The local chat catalog could not be read.";
								}
							};
							reading.oncomplete = () => {
								transaction = void 0;
								if (failed !== null) {
									finish(failure$1(failed));
									return;
								}
								if (count === void 0 || count !== visited || count > MAX_CHATS) {
									finish(failure$1("The complete local chat catalog exceeds the supported entry limit."));
									return;
								}
								finish({
									ok: true,
									chats: output,
									scope: "local-cache"
								});
							};
						} catch {
							finish(failure$1("The local chat catalog could not be read."));
						}
					};
				} catch {
					finish(failure$1("The existing local chat database could not be inspected."));
				}
			})();
		});
	}
	//#endregion
	//#region src/original-metadata.ts
	var DATABASE = "model-storage";
	var TIMEOUT_MS = 3e3;
	var MAX_FILE = 8388608;
	var MESSAGE_KEY = /^(?:true|false)_\d+(?:-\d+)?(?::\d+)?@(?:c\.us|g\.us|lid|s\.whatsapp\.net)_[^_\s]+(?:_\d+(?::\d+)?@(?:c\.us|lid|s\.whatsapp\.net))?$/;
	var failure = (reason) => ({
		ok: false,
		reason
	});
	function supportedKey(value) {
		return value.length <= 512 && !/[\x00-\x1f\x7f]/u.test(value) && MESSAGE_KEY.test(value);
	}
	function record(value) {
		return typeof value === "object" && value !== null && !Array.isArray(value);
	}
	function plaintextDigest(value) {
		let bytes;
		if (typeof value === "string") {
			if (/^[0-9a-f]{64}$/i.test(value)) return value.toLowerCase();
			if (!/^[A-Za-z0-9+/]{43}=$/.test(value)) return null;
			const decoded = atob(value);
			if (decoded.length !== 32 || btoa(decoded) !== value) return null;
			bytes = Uint8Array.from(decoded, (character) => character.charCodeAt(0));
		} else if (value instanceof Uint8Array && value.byteLength === 32) bytes = value;
		else return null;
		return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
	}
	/** Project only selected identity and plaintext media evidence; message contents stay opaque. */
	function projectOriginalMetadata(messageId, value) {
		if (!supportedKey(messageId) || !record(value) || !Object.hasOwn(value, "id") || value.id !== messageId || !Object.hasOwn(value, "filehash")) return null;
		const digest = plaintextDigest(value.filehash);
		if (!digest) return null;
		let size = null, mediaType = null, name = null;
		if (value.size !== void 0 && value.size !== null) {
			if (typeof value.size !== "number" || !Number.isSafeInteger(value.size) || value.size < 0 || value.size > MAX_FILE) return null;
			size = value.size;
		}
		if (value.mimetype !== void 0 && value.mimetype !== null) {
			if (typeof value.mimetype !== "string" || value.mimetype.length > 256 || /[\x00-\x1f\x7f]/u.test(value.mimetype)) return null;
			mediaType = value.mimetype.split(";", 1)[0]?.trim().toLowerCase() ?? null;
			if (!mediaType || mediaType.length > 128 || !/^[a-z0-9!#$&^_.+-]+\/[a-z0-9!#$&^_.+-]+$/.test(mediaType)) return null;
		}
		if (value.filename !== void 0 && value.filename !== null) {
			if (typeof value.filename !== "string" || !value.filename.trim() || value.filename.length > 256 || /[\x00-\x1f\x7f/\\:]/u.test(value.filename)) return null;
			name = value.filename;
		}
		return {
			digest,
			size,
			mediaType,
			name
		};
	}
	/** One exact primary-key lookup, never a scan or access to private endpoints. */
	async function readMessageOriginal(messageId, signal) {
		if (!supportedKey(messageId)) return failure("The attachment message identity is unsupported.");
		if (signal?.aborted) return failure("Original attachment metadata lookup was stopped.");
		const deadline = Date.now() + TIMEOUT_MS;
		return new Promise((resolve) => {
			let settled = false, database, transaction;
			const finish = (result) => {
				if (settled) return;
				settled = true;
				clearTimeout(timer);
				signal?.removeEventListener("abort", abort);
				try {
					transaction?.abort();
				} catch {}
				database?.close();
				resolve(result.ok && Date.now() >= deadline ? failure("Original attachment metadata lookup timed out.") : result);
			};
			const abort = () => finish(failure("Original attachment metadata lookup was stopped."));
			const timer = setTimeout(() => finish(failure("Original attachment metadata lookup timed out.")), TIMEOUT_MS);
			signal?.addEventListener("abort", abort, { once: true });
			if (signal?.aborted) {
				abort();
				return;
			}
			(async () => {
				try {
					const existing = (await indexedDB.databases()).filter((info) => info.name === DATABASE);
					if (settled) return;
					if (existing.length !== 1) {
						finish(failure("The local message database is not ready. Wait for WhatsApp to finish loading and retry."));
						return;
					}
					const opening = indexedDB.open(DATABASE);
					opening.onupgradeneeded = () => {
						opening.transaction?.abort();
						finish(failure("The local message database changed; no upgrade was performed."));
					};
					opening.onblocked = () => finish(failure("The local message database is temporarily blocked."));
					opening.onerror = () => finish(failure("The local message database could not be opened."));
					opening.onsuccess = () => {
						const opened = opening.result;
						if (settled) {
							opened.close();
							return;
						}
						database = opened;
						opened.onversionchange = () => finish(failure("The local message database changed during attachment lookup."));
						try {
							if (!opened.objectStoreNames.contains("message")) {
								finish(failure("The local message database schema is unsupported."));
								return;
							}
							const reading = opened.transaction("message", "readonly");
							transaction = reading;
							reading.onabort = () => finish(failure("Original attachment metadata lookup was interrupted."));
							reading.onerror = () => finish(failure("Original attachment metadata could not be read."));
							const store = reading.objectStore("message");
							if (store.keyPath !== "id") {
								finish(failure("The local message database schema is unsupported."));
								return;
							}
							let result = null;
							const request = store.get(messageId);
							request.onsuccess = () => {
								result = projectOriginalMetadata(messageId, request.result);
							};
							reading.oncomplete = () => {
								transaction = void 0;
								finish(result ? {
									ok: true,
									value: result
								} : failure("This message has no supported original attachment hash."));
							};
						} catch {
							finish(failure("Original attachment metadata could not be read."));
						}
					};
				} catch {
					finish(failure("The existing local message database could not be inspected."));
				}
			})();
		});
	}
	//#endregion
	//#region local/page-entry.ts
	async function row(messageId) {
		const main = document.querySelector("#main"), account = accountId();
		if (!main || !account) return {
			ok: false,
			reason: "The source conversation is unavailable."
		};
		const nodes = Array.from(main.querySelectorAll("[data-id]")).filter((node) => !node.closest("[data-testid='quoted-message']"));
		const opaque = [...new Set(nodes.map((node) => node.getAttribute("data-id") ?? "").filter((id) => /^(?:[0-9a-f]{20}|[0-9a-f]{32})$/i.test(id)))];
		const keys = opaque.length ? await resolveLocalMessageKeys(opaque) : null;
		if (keys && !keys.ok) return keys;
		if (accountId() !== account || document.querySelector("#main") !== main) return {
			ok: false,
			reason: "The source changed during attachment lookup."
		};
		const matched = nodes.filter((node) => {
			const raw = node.getAttribute("data-id") ?? "";
			return raw === messageId || keys?.ok && keys.keys.get(raw)?.id === messageId;
		});
		const node = matched[0];
		if (matched.length !== 1 || !node?.isConnected) return {
			ok: false,
			reason: "The attachment's message is missing or ambiguous."
		};
		if (Array.from(node.querySelectorAll("[data-icon='recalled'],[data-icon='recalled-out'],[data-testid='recalled']")).some((marker) => !marker.closest("[data-testid='quoted-message']"))) return {
			ok: false,
			reason: "WhatsApp reports this message deleted."
		};
		return {
			ok: true,
			rawId: node.getAttribute("data-id") ?? "",
			text: messageText(node)
		};
	}
	if (location.origin === "https://web.whatsapp.com") window.waScribeLocal = {
		account: accountId,
		inspect: inspectWhatsAppResolved,
		catalog: readLocalChatCatalog,
		collect: collectWhatsApp,
		original: readMessageOriginal,
		row
	};
	//#endregion
})();
